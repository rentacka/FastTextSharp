﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastText
{
    public class Args
    {
        public enum model_name : int
        {
            cbow = 1,
            sg,
            sup
        }
        public enum loss_name : int
        {
            hs = 1,
            ns,
            softmax
        }

        /// <summary>
        /// 読み込みテキストファイル名
        /// </summary>
        public string input;
        string test;
        public string outputName;
        internal double lr;
        internal int lrUpdateRate;
        /// <summary>
        /// 分類の大きさ
        /// </summary>
        internal int dim;
        /// <summary>
        /// ランダム値の最大値
        /// </summary>
        internal int ws;
        internal int epoch;
        internal int minCount;
        internal int minCountLabel;
        internal int neg;

        // これの意味は？
        public int wordNgrams;
        public loss_name loss = new loss_name();
        public model_name model = new model_name();
        internal int bucket;
        internal int minn;
        internal int maxn;
        internal int thread;
        internal double t;
        internal string label;
        internal int verbose;
        public string pretrainedVectors;
        internal int saveOutput;

        bool qout = false;
        bool retrain = false;
        bool  qnorm = false;
        int  cutoff = 0;
        int  dsub = 2;

        public Args()
        {
            lr = 0.05;
            // 分類の大きさ
            dim = 10;
            ws = 5;
            epoch = 5;
            minCount = 5;
            minCountLabel = 0;
            neg = 5;
            wordNgrams = 1;
            loss = loss_name.ns;
            model = model_name.sg;
            bucket = 2000000;
            minn = 3;
            maxn = 6;
            thread = 0;
            lrUpdateRate = 100;
            t = 1e-4;
            label = "__label__";
            verbose = 2;
            pretrainedVectors = "";
            saveOutput = 0;
        }

        public void parseArgs(int argc, string[] argv)
        {
            string command = argv[1];
            if (command == "supervised")
            {
                model = model_name.sup;
                loss = loss_name.softmax;
                minCount = 1;
                minn = 0;
                maxn = 0;
                lr = 0.1;
            }
            else if (command == "cbow")
            {
                model = model_name.cbow;
            }
            int ai = 2;
            while (ai < argc)
            {
                if (argv[ai][0] != '-')
                {
                    Console.Write("Provided argument without a dash! Usage:");
                    Console.Write("\n");
                    printHelp();
                    Environment.Exit(1);
                }
                if (string.Compare(argv[ai], "-h") == 0)
                {
                    Console.Write("Here is the help! Usage:");
                    Console.Write("\n");
                    printHelp();
                    Environment.Exit(1);
                }
                else if (string.Compare(argv[ai], "-input") == 0)
                {
                    input = (string)argv[ai + 1];
                }
                else if (string.Compare(argv[ai], "-test") == 0)
                {
                    test = (string)argv[ai + 1];
                }
                else if (string.Compare(argv[ai], "-output") == 0)
                {
                    outputName = (string)argv[ai + 1];
                }
                else if (string.Compare(argv[ai], "-lr") == 0)
                {
                    lr = Convert.ToDouble(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-lrUpdateRate") == 0)
                {
                    lrUpdateRate = Convert.ToInt32(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-dim") == 0)
                {
                    dim = Convert.ToInt32(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-ws") == 0)
                {
                    ws = Convert.ToInt32(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-epoch") == 0)
                {
                    epoch = Convert.ToInt32(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-minCount") == 0)
                {
                    minCount = Convert.ToInt32(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-minCountLabel") == 0)
                {
                    minCountLabel = Convert.ToInt32(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-neg") == 0)
                {
                    neg = Convert.ToInt32(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-wordNgrams") == 0)
                {
                    wordNgrams = Convert.ToInt32(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-loss") == 0)
                {
                    if (string.Compare(argv[ai + 1], "hs") == 0)
                    {
                        loss = loss_name.hs;
                    }
                    else if (string.Compare(argv[ai + 1], "ns") == 0)
                    {
                        loss = loss_name.ns;
                    }
                    else if (string.Compare(argv[ai + 1], "softmax") == 0)
                    {
                        loss = loss_name.softmax;
                    }
                    else
                    {
                        Console.Write("Unknown loss: ");
                        Console.Write(argv[ai + 1]);
                        Console.Write("\n");
                        printHelp();
                        Environment.Exit(1);
                    }
                }
                else if (string.Compare(argv[ai], "-bucket") == 0)
                {
                    bucket = Convert.ToInt32(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-minn") == 0)
                {
                    minn = Convert.ToInt32(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-maxn") == 0)
                {
                    maxn = Convert.ToInt32(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-thread") == 0)
                {
                    thread = Convert.ToInt32(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-t") == 0)
                {
                    t = Convert.ToDouble(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-label") == 0)
                {
                    label = (string)argv[ai + 1];
                }
                else if (string.Compare(argv[ai], "-verbose") == 0)
                {
                    verbose = Convert.ToInt32(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-pretrainedVectors") == 0)
                {
                    pretrainedVectors = (string)argv[ai + 1];
                }
                else if (string.Compare(argv[ai], "-saveOutput") == 0)
                {
                    saveOutput = Convert.ToInt32(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-qnorm") == 0)
                {
                    qnorm = true;
                    ai--;
                }
                else if (string.Compare(argv[ai], "-retrain") == 0)
                {
                    retrain = true;
                    ai--;
                }
                else if (string.Compare(argv[ai], "-qout") == 0)
                {
                    qout = true;
                    ai--;
                }
                else if (string.Compare(argv[ai], "-cutoff") == 0)
                {
                    cutoff = Convert.ToInt32(argv[ai + 1]);
                }
                else if (string.Compare(argv[ai], "-dsub") == 0)
                {
                    dsub = Convert.ToInt32(argv[ai + 1]);
                }
                else
                {
                    Console.Write("Unknown argument: ");
                    Console.Write(argv[ai]);
                    Console.Write("\n");
                    printHelp();
                    Environment.Exit(1);
                }
                ai += 2;
            }
            if (input== null || outputName == null)
            {
                Console.Write("Empty input or output path.");
                Console.Write("\n");
                printHelp();
                Environment.Exit(1);
            }
            if (wordNgrams <= 1 && maxn == 0)
            {
                bucket = 0;
            }
        }

        public void printHelp()
        {
            string lname = "ns";
            if (loss == loss_name.hs)
            {
                lname = "hs";
            }
            if (loss == loss_name.softmax)
            {
                lname = "softmax";
            }
            Console.Write("\n");
            Console.Write("The following arguments are mandatory:\n");
            Console.Write("  -input              training file path\n");
            Console.Write("  -output             output file path\n\n");
            Console.Write("The following arguments are optional:\n");
            Console.Write("  -lr                 learning rate [");
            Console.Write(lr);
            Console.Write("]\n");
            Console.Write("  -lrUpdateRate       change the rate of updates for the learning rate [");
            Console.Write(lrUpdateRate);
            Console.Write("]\n");
            Console.Write("  -dim                size of word vectors [");
            Console.Write(dim);
            Console.Write("]\n");
            Console.Write("  -ws                 size of the context window [");
            Console.Write(ws);
            Console.Write("]\n");
            Console.Write("  -epoch              number of epochs [");
            Console.Write(epoch);
            Console.Write("]\n");
            Console.Write("  -minCount           minimal number of word occurences [");
            Console.Write(minCount);
            Console.Write("]\n");
            Console.Write("  -minCountLabel      minimal number of label occurences [");
            Console.Write(minCountLabel);
            Console.Write("]\n");
            Console.Write("  -neg                number of negatives sampled [");
            Console.Write(neg);
            Console.Write("]\n");
            Console.Write("  -wordNgrams         max length of word ngram [");
            Console.Write(wordNgrams);
            Console.Write("]\n");
            Console.Write("  -loss               loss function {ns, hs, softmax} [ns]\n");
            Console.Write("  -bucket             number of buckets [");
            Console.Write(bucket);
            Console.Write("]\n");
            Console.Write("  -minn               min length of char ngram [");
            Console.Write(minn);
            Console.Write("]\n");
            Console.Write("  -maxn               max length of char ngram [");
            Console.Write(maxn);
            Console.Write("]\n");
            Console.Write("  -thread             number of threads [");
            Console.Write(thread);
            Console.Write("]\n");
            Console.Write("  -t                  sampling threshold [");
            Console.Write(t);
            Console.Write("]\n");
            Console.Write("  -label              labels prefix [");
            Console.Write(label);
            Console.Write("]\n");
            Console.Write("  -verbose            verbosity level [");
            Console.Write(verbose);
            Console.Write("]\n");
            Console.Write("  -pretrainedVectors  pretrained word vectors for supervised learning []");
            Console.Write("  -saveOutput         whether output params should be saved [");
            Console.Write(saveOutput);
            Console.Write("]\n");
            Console.Write("\n");
        }

        public void save(BinaryWriter outStream)
        {
            outStream.Write(dim);
            outStream.Write(ws);
            outStream.Write(epoch);
            outStream.Write(minCount);
            outStream.Write(neg);
            outStream.Write(wordNgrams);

            outStream.Write((int)loss);

            outStream.Write((int)model);

            outStream.Write(bucket);
            outStream.Write(minn);
            outStream.Write(maxn);
            outStream.Write(lrUpdateRate);

            outStream.Write(t);
        }

        public void load(BinaryReader inStream)
        {
            dim = inStream.ReadInt32();
            ws = inStream.ReadInt32();
            epoch = inStream.ReadInt32();
            minCount = inStream.ReadInt32();
            neg = inStream.ReadInt32();
            wordNgrams = inStream.ReadInt32();

            loss = (loss_name)inStream.ReadInt32();

            model = (model_name)inStream.ReadInt32();

            bucket = inStream.ReadInt32();
            minn = inStream.ReadInt32();
            maxn = inStream.ReadInt32();
            lrUpdateRate = inStream.ReadInt32();

            t = inStream.ReadDouble();
        }
    }
}
