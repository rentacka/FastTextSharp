﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static FastText.Args;

namespace FastText
{
    internal class Dictionary
    {
        internal class VocubComparer : IComparer<VocubEntry>
        {
            public int Compare(VocubEntry x, VocubEntry y)
            {
                /*
                if (x.type != y.type)
                {
                    return (int)x.type + (int)y.type;
                }
                */

                return (int)(y.count - x.count);
            }
        }

        private const int MAX_VOCAB_SIZE = 30000000;
        private const int MAX_LINE_SIZE = 1024;

        public enum entry_type : sbyte
        {
            word = 0,
            label = 1
        }

        public class VocubEntry
        {
            public string word;
            /// <summary>
            /// 文章データ中のその単語がでてきた回数
            /// </summary>
            public long count;
            public entry_type type;
            public List<int> subwords = new List<int>();

            public int CompareTo(VocubEntry other)
            {
                return (int)(this.count - other.count);
            }
        }

        private Args args_;
        private int[] word2int_;
        private List<VocubEntry> vocabWords_ = new List<VocubEntry>();
        private double[] pdiscard_ = null;
        private int size_;
        private int nwords_;
        private int nlabels_;
        private long ntokens_;

        long pruneidx_size_ = -1;
        Dictionary<int, int> pruneidx_ = new Dictionary<int, int>();

        private const string EOS = "</s>";
        private const string BOW = "<";
        private const string EOW = ">";

        public Dictionary(Args args)
        {
            args_ = args;
            size_ = 0;
            nwords_ = 0;
            nlabels_ = 0;
            ntokens_ = 0;
            word2int_=new int[MAX_VOCAB_SIZE];
            for (int i = 0; i < MAX_VOCAB_SIZE; i++)
            {
                word2int_[i] = -1;
            }
        }
        public int find(string w)
        {
            var h = hash(w) % MAX_VOCAB_SIZE;
            while (word2int_[h] != -1 && vocabWords_[word2int_[h]].word != w)
            {
                h = (h + 1) % MAX_VOCAB_SIZE;
            }
            return (int)h;
        }

        public void add(string w)
        {
            int h = find(w);
            ntokens_++;
            if (word2int_[h] == -1)
            {
                VocubEntry e = new VocubEntry();
                e.word = w;
                e.count = 1;
                e.type = (w.IndexOf(args_.label) == 0) ? entry_type.label : entry_type.word;
                vocabWords_.Add(e);
                // TODO:size_ = size_++;
                size_ = size_++;
                word2int_[h] = size_++;
            }
            else
            {
                vocabWords_[word2int_[h]].count++;
            }
        }

        public long nwords()
        {
            return nwords_;
        }
        public int nlabels()
        {
            return nlabels_;
        }
        public long ntokens()
        {
            return ntokens_;
        }

        #region getNgrams
        public List<int> getNgrams(int i)
        {
            Debug.Assert(i >= 0);
            Debug.Assert(i < nwords_);
            return vocabWords_[i].subwords;
        }
        public List<int> getNgrams(string word)
        {
            int i = getId(word);
            if (i >= 0)
            {
                return getNgrams(i);
            }
            List<int> ngrams = new List<int>();
            computeNgrams(BOW + word + EOW, ngrams);
            return ngrams;
        }

        public void getNgrams(string word, List<int> ngrams, List<string> substrings)
        {
            int i = getId(word);
            ngrams.Clear();
            substrings.Clear();
            if (i >= 0)
            {
                ngrams.Add(i);
                substrings.Add(vocabWords_[i].word);
            }
            else
            {
                ngrams.Add(-1);
                substrings.Add(word);
            }
            computeNgrams(BOW + word + EOW, ngrams, substrings);
        }
        #endregion getNgrams

        public bool discard(int id, double rand)
        {
            Debug.Assert(id >= 0);
            Debug.Assert(id < nwords_);
            if (args_.model == model_name.sup)
            {
                return false;
            }
            return rand > pdiscard_[id];
        }
        public int getId(string w)
        {
            int h = find(w);
            return word2int_[h];
        }
        public entry_type getType(int id)
        {
            Debug.Assert(id >= 0);
            Debug.Assert(id < size_);
            return vocabWords_[id].type;
        }
        public entry_type getType(string w)
        {
            return (w.IndexOf(args_.label) == 0) ? entry_type.label : entry_type.word;
        }
        public string getWord(int id)
        {
            Debug.Assert(id >= 0);
            Debug.Assert(id < size_);
            return vocabWords_[id].word;
        }
        public uint hash(string str)
        {
            uint h = 2166136261;
            for (int i = 0; i < str.Length; i++)
            {
                h = h ^ (uint)str[i];
                h = h * 16777619;
            }
            return h;
        }

        #region computeNgrams
        public void computeNgrams(string word, List<int> ngrams, List<string> substrings)
        {
            for (int i = 0; i < word.Length; i++)
            {
                string ngram = null;
                if ((word[i] & 0xC0) == 0x80)
                {
                    continue;
                }

                for (int j = i, n = 1; j < word.Length && n <= args_.maxn; n++)
                {
                    ngram +=word[j++];
                    while (j < word.Length && (word[j] & 0xC0) == 0x80)
                    {
                        ngram += word[j++];
                    }

                    if (n >= args_.minn && !(n == 1 && (i == 0 || j == word.Length)))
                    {
                        var h = (int)(hash(ngram) % args_.bucket);
                        ngrams.Add(nwords_ + h);
                        substrings.Add(ngram);
                    }
                }
            }
        }

        public void computeNgrams(string word, List<int> ngrams)
        {
            for (int i = 0; i < word.Length; i++)
            {
                string ngram = null;
                if ((word[i] & 0xC0) == 0x80)
                {
                    continue;
                }
                for (int j = i, n = 1; j < word.Length && n <= args_.maxn; n++)
                {
                    ngram+=word[j++];
                    while (j < word.Length && (word[j] & 0xC0) == 0x80)
                    {
                        ngram+=word[j++];
                    }
                    if (n >= args_.minn && !(n == 1 && (i == 0 || j == word.Length)))
                    {
                        var h = (int)(hash(ngram) % args_.bucket);
                        ngrams.Add(nwords_ + h);
                    }
                }
            }
        }
        #endregion computeNgrams

        #region Read
        public void initNgrams()
        {
            for (int i = 0; i < size_; i++)
            {
                string word = BOW + vocabWords_[i].word + EOW;
                vocabWords_[i].subwords.Add(i);
                computeNgrams(word, vocabWords_[i].subwords);
            }
        }

        /*
        public bool readWord(TextReader inStream,out string word)
        {
            var sb = inStream.ReadLine();
            word = sb;

            // 空白やら改行はEOSに変更
//             	  sbyte c;
//	  std::streambuf sb = in.rdbuf();
	//  word = "";
	  //while ((c = sb.sbumpc()) != EOF)
	//  {
//		if (c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == '\v' || c == '\f' || c == '\0')
		//{
		  //if (string.IsNullOrEmpty(word))
		  //{
			//if (c == '\n')
//			{
	//		  word += EOS;
		//	  return true;
			//}
//			continue;
		//  }
		  //else
		  //{
			//if (c == '\n')
			//{
			  //sb.sungetc();
			//}
			//return true;
		  //}
		//}
		//word.push_back(c);
	  //}
            return !string.IsNullOrEmpty(word);
        }
        */

        public void readFromFile(FileStream inStream)
        {
            long minThreshold = 1;

            var sr = new StreamReader(inStream, Encoding.GetEncoding(932));
            var substance = sr.ReadToEnd().Split(" ".ToCharArray());

            foreach (var word in substance)
            {
                add(word);
                if (ntokens_ % 1000000 == 0 && args_.verbose > 1)
                {
                    Console.Write("\rRead ");
                    Console.Write(ntokens_ / 1000000);
                    Console.Write("M words");
                }
                if (size_ > 0.75 * MAX_VOCAB_SIZE)
                {
                    minThreshold++;
                    threshold(minThreshold, minThreshold);
                }
            }
            threshold(args_.minCount, args_.minCountLabel);
            initTableDiscard();
            initNgrams();
            if (args_.verbose > 0)
            {
                Console.Write("\rRead ");
                Console.Write(ntokens_ / 1000000);
                Console.Write("M words");
                Console.Write("\n");
                Console.Write("Number of words:  ");
                Console.Write(nwords_);
                Console.Write("\n");
                Console.Write("Number of labels: ");
                Console.Write(nlabels_);
                Console.Write("\n");
            }
            if (size_ == 0)
            {
                Environment.Exit(1);
            }
        }

        public void threshold(long t, long tl)
        {
            vocabWords_.Sort(0, vocabWords_.Count,new VocubComparer());

            // shrink_to_fit:キャパシティを現在のサイズの値にし、余分なメモリを解放
            for (int i=0; i<vocabWords_.Count;i++)
            {
                var e = vocabWords_[i];
                if ((e.type == entry_type.word && e.count < t) || (e.type == entry_type.label && e.count < tl))
                    vocabWords_.Remove(e);
            }

            size_ = 0;
            nwords_ = 0;
            nlabels_ = 0;
            for (int i = 0; i < MAX_VOCAB_SIZE; i++)
            {
                word2int_[i] = -1;
            }
            for (int i = 0; i< vocabWords_.Count; i++)
            {
                var it = vocabWords_[i];
                int h = find(it.word);
                word2int_[h] = size_++;
                if (it.type == entry_type.word)
                {
                    nwords_++;
                }
                if (it.type == entry_type.label)
                {
                    nlabels_++;
                }
            }
        }

        public void initTableDiscard()
        {
            Array.Resize(ref pdiscard_, size_);

            for (int i = 0; i < size_; i++)
            {
                var f = ((float)vocabWords_[i].count) / ((float)ntokens_);
                pdiscard_[i] = Math.Sqrt((double)args_.t / (double)f) + (double)args_.t / (double)f;
            }
        }
        #endregion Read


        public List<long> getCounts(entry_type type)
        {
            List<long> counts = new List<long>();
            foreach (var w in vocabWords_)
            {
                if (w.type == type)
                {
                    counts.Add(w.count);
                }
            }
            return counts;
        }

        public void addNgrams(List<int> line, List<int> hashes, int n)
        {
            if (pruneidx_size_ == 0)
            {
                return;
            }
            for (int i = 0; i < hashes.Count; i++)
            {
                ulong h = (ulong)hashes[i];
                for (int j = i + 1; j < hashes.Count && j < i + n; j++)
                {
                    h = h * 116049371 + (ulong)hashes[j];
                    var id = (int)(h % (ulong)args_.bucket);
                    if (pruneidx_size_ > 0)
                    {
                        if (pruneidx_.ContainsKey(id))
                        {
                            id = pruneidx_[id];
                        }
                        else
                        {
                            continue;
                        }
                    }
                    line.Add(nwords_ + id);
                }
            }
        }



        public int getLine(StreamReader inStream, List<int> words, List<int> word_hashes, List<int> labels, int rng)
        {
            var round = new Random(rng);
            var uniform = round.NextDouble();
            int ntokens = 0;
            words.Clear();
            labels.Clear();

            var substance = inStream.ReadLine().Split(" ".ToCharArray());
            foreach(var token in substance)
            {
                int wid = getId(token);
                if (wid < 0)
                {
                    continue;
                }
                entry_type type = getType(wid);
                ntokens++;
                if (type == entry_type.word && !discard(wid, uniform))
                {
                    words.Add(wid);
                }
                if (type == entry_type.label)
                {
                    labels.Add(wid - nwords_);
                }
                if (words.Count > MAX_LINE_SIZE && args_.model != model_name.sup)
                {
                    break;
                }

                // 行の端
                /*
                if (token == EOS)
                {
                    break;
                }
                */
            }
            return ntokens;
        }

        public int getLine(StreamReader inStream, List<int> words, List<int> labels, int rng)
        {
            List<int> word_hashes = new List<int>();
            int ntokens = getLine(inStream, words, word_hashes, labels, rng);
            if (args_.model == model_name.sup)
            {
                addNgrams(words, word_hashes, args_.wordNgrams);
            }
            return ntokens;
        }

        public string getLabel(int lid)
        {
            Debug.Assert(lid >= 0);
            Debug.Assert(lid < nlabels_);
            return vocabWords_[lid + nwords_].word;
        }
        public void save(BinaryWriter outStream )
        {
            outStream.Write(size_);
            outStream.Write(nwords_);
            outStream.Write(nlabels_);
            outStream.Write(ntokens_);
            for (int i = 0; i < size_; i++)
            {
                VocubEntry e = vocabWords_[i];
                outStream.Write(e.word);

                outStream.Write(e.count);
                outStream.Write((int)e.type);
            }

            foreach (var pair in pruneidx_)
            {
                outStream.Write(pair.Key);
                outStream.Write(pair.Value);
            }

        }

        public void load(BinaryReader inStream)
        {
            vocabWords_.Clear();
            for (int i = 0; i < MAX_VOCAB_SIZE; i++)
            {
                word2int_[i] = -1;
            }

            size_ = inStream.ReadInt32();
            nwords_ = inStream.ReadInt32();
            nlabels_ = inStream.ReadInt32();
            ntokens_ = inStream.ReadInt32();
            for (int i = 0; i < size_; i++)
            {
                VocubEntry e = new VocubEntry();
                e.word = inStream.ReadString();

                e.count = inStream.ReadInt32();
                e.type = (entry_type)inStream.ReadInt32();

                vocabWords_.Add(e);
                word2int_[find(e.word)] = i;
            }

            pruneidx_.Clear();
            for (int i = 0; i < pruneidx_size_; i++)
            {
                int first = inStream.ReadInt32();
                int second = inStream.ReadInt32();

                pruneidx_[first] = second;
            }

            initTableDiscard();
            initNgrams();
        }

        /// <summary>
        /// vocabWords_をクリア
        /// </summary>
        /// <param name="idx"></param>
        public void prune(ref List<int> idx)
        {
            List<int> words = new List<int>();
            List<int> ngrams = new List<int>();
            foreach (var it in idx)
            {
                if (it < nwords_)
                {
                    words.Add(it);
                }
                else
                {
                    ngrams.Add(it);
                }
            }
            words.Sort();
            idx = words;

            if (ngrams.Count != 0)
            {
                int jj = 0;
                foreach (var ngram in ngrams)
                {
                    pruneidx_[ngram - nwords_] = jj;
                    jj++;
                }
                idx.AddRange(ngrams);
            }
            pruneidx_size_ = pruneidx_.Count;

            for (int i = 0; i < word2int_.Count(); i++)
                word2int_[i] = -1;

            int j = 0;
            for (int i = 0; i < vocabWords_.Count; i++)
            {
                if (getType(i) == entry_type.label || (j < words.Count && words[j] == i))
                {
                    vocabWords_[j] = vocabWords_[i];
                    word2int_[find(vocabWords_[j].word)] = j;
                    j++;
                }
            }
            nwords_ = words.Count;
            size_ = nwords_ + nlabels_;

            vocabWords_.Clear();
        }

    }
}