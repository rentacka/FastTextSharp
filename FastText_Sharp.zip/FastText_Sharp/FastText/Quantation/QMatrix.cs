﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastText
{
    class QMatrix
    {
        //std::unique_ptr<ProductQuantizer> pq_ = new std::unique_ptr<ProductQuantizer>();
        //std::unique_ptr<ProductQuantizer> npq_ = new std::unique_ptr<ProductQuantizer>();

        //C++ TO C# CONVERTER TODO TASK: C# does not have an equivalent to pointers to value types:
        //ORIGINAL LINE: byte* codes_;
        byte[] codes_;
        //C++ TO C# CONVERTER TODO TASK: C# does not have an equivalent to pointers to value types:
        //ORIGINAL LINE: byte* norm_codes_;
        byte[] norm_codes_;

        bool qnorm_;

        long m_;
        long n_;

        int codesize_;


        public QMatrix()
        {
            this.qnorm_ = false;
            this.m_ = 0;
            this.n_ = 0;
            this.codesize_ = 0;
        }
        public QMatrix(Matrix mat, int dsub, bool qnorm)
        {
            this.qnorm_ = qnorm;
            this.m_ = mat.m_;
            this.n_ = mat.n_;
            this.codesize_ = (int)((decimal)m_ * Math.Ceiling((decimal)(n_ / (long)dsub)));
            codes_ = new byte[codesize_];
            pq_ = std::unique_ptr<ProductQuantizer>(new ProductQuantizer(n_, dsub));
            if (qnorm_)
            {
                norm_codes_ = new byte[m_];
                npq_ = std::unique_ptr<ProductQuantizer>(new ProductQuantizer(1, 1));
            }
            quantize(mat);
        }

        public void quantizeNorm(Vector norms)
        {
            Debug.Assert(qnorm_);
            Debug.Assert(norms.m_ == m_);
            var dataptr = norms.data_;
            npq_.train(m_, dataptr);
            npq_.compute_codes(dataptr, norm_codes_, m_);
        }
        public void quantize(Matrix matrix)
        {
            Debug.Assert(n_ == matrix.n_);
            Debug.Assert(m_ == matrix.m_);
            Matrix temp = new Matrix(matrix);
            if (qnorm_)
            {
                Vector norms = new Vector(temp.m_);
                temp.l2NormRow(norms);
                temp.divideRow(norms);
                quantizeNorm(norms);
            }
            var dataptr = temp.data_;
            pq_.train(m_, dataptr);
            pq_.compute_codes(dataptr, codes_, m_);
        }

        public void addToVector(Vector x, int t)
        {
            float norm = 1;
            if (qnorm_)
            {
                norm = npq_.get_centroids(0, norm_codes_[t])[0];
            }
            pq_.addcode(x, codes_, t, norm);
        }
        public float dotRow(Vector vec, long i)
        {
            Debug.Assert(i >= 0);
            Debug.Assert(i < m_);
            Debug.Assert(vec.size() == n_);
            float norm = 1;
            if (qnorm_)
            {
                norm = npq_.get_centroids(0, norm_codes_[i])[0];
            }
            return pq_.mulcode(vec, codes_, i, norm);
        }
        public long getM()
        {
            return m_;
        }
        public long getN()
        {
            return n_;
        }
        public void save(std::ostream @out)
        {
            @out.write((string)&qnorm_, sizeof(qnorm_));
            @out.write((string)&m_, sizeof(m_));
            @out.write((string)&n_, sizeof(n_));
            @out.write((string)&codesize_, sizeof(codesize_));
            @out.write((string)codes_, codesize_ * sizeof(byte));
            pq_.save(@out);
            if (qnorm_)
            {
                @out.write((string)norm_codes_, m_ * sizeof(byte));
                npq_.save(@out);
            }
        }

        public void load(std::istream in)
        {
		in.read((string)&qnorm_, sizeof(qnorm_));
		in.read((string)&m_, sizeof(m_));
		in.read((string)&n_, sizeof(n_));
		in.read((string)&codesize_, sizeof(codesize_));
            codes_ = new byte[codesize_];
		in.read((string)codes_, codesize_ * sizeof(byte));
            pq_ = std::unique_ptr<ProductQuantizer>(new ProductQuantizer());
            pq_.load(in);
            if (qnorm_)
            {
                norm_codes_ = new byte[m_];
		  in.read((string)norm_codes_, m_ * sizeof(byte));
                npq_ = std::unique_ptr<ProductQuantizer>(new ProductQuantizer());
                npq_.load(in);
            }
        }
    }
}
