﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FastText
{
    //----------------------------------------------------------------------------------------
    //	Copyright © 2006 - 2017 Tangible Software Solutions Inc.
    //	This class can be used by anyone provided that the copyright notice remains intact.
    //
    //	This class provides the ability to convert basic C++ 'cin' and C 'scanf' behavior.
    //----------------------------------------------------------------------------------------
    internal static class ConsoleInput
    {
        private static bool goodLastRead = false;
        internal static bool LastReadWasGood
        {
            get
            {
                return goodLastRead;
            }
        }

        internal static string ReadToWhiteSpace(bool skipLeadingWhiteSpace)
        {
            string input = "";

            char nextChar;
            while (char.IsWhiteSpace(nextChar = (char)System.Console.Read()))
            {
                //accumulate leading white space if skipLeadingWhiteSpace is false:
                if (!skipLeadingWhiteSpace)
                    input += nextChar;
            }
            //the first non white space character:
            input += nextChar;

            //accumulate characters until white space is reached:
            while (!char.IsWhiteSpace(nextChar = (char)System.Console.Read()))
            {
                input += nextChar;
            }

            goodLastRead = input.Length > 0;
            return input;
        }

        internal static string ScanfRead(string unwantedSequence = null, int maxFieldLength = -1)
        {
            string input = "";

            char nextChar;
            if (unwantedSequence != null)
            {
                nextChar = '\0';
                for (int charIndex = 0; charIndex < unwantedSequence.Length; charIndex++)
                {
                    if (char.IsWhiteSpace(unwantedSequence[charIndex]))
                    {
                        //ignore all subsequent white space:
                        while (char.IsWhiteSpace(nextChar = (char)System.Console.Read()))
                        {
                        }
                    }
                    else
                    {
                        //ensure each character matches the expected character in the sequence:
                        nextChar = (char)System.Console.Read();
                        if (nextChar != unwantedSequence[charIndex])
                            return null;
                    }
                }

                input = nextChar.ToString();
                if (maxFieldLength == 1)
                    return input;
            }

            while (!char.IsWhiteSpace(nextChar = (char)System.Console.Read()))
            {
                input += nextChar;
                if (maxFieldLength == input.Length)
                    return input;
            }

            return input;
        }
    }

    public class Fast2Vec
    {
        public const int FASTTEXT_VERSION = 11; // Version 1a
        public const int FASTTEXT_FILEFORMAT_MAGIC_INT32 = 793712314;

        Args args_;
        Dictionary dict_;
        Matrix input_;
        Matrix output_;
        Model model_;
        //std::atomic<long> tokenCount = new std::atomic<long>();
        //clock_t start = new clock_t();

        bool quant_;

        void getVector(Vector vec, string word)
        {
            var ngrams = Ngram.GetNGrams(word);

            vec.zero();
            for (int i = 0; i < ngrams.Count(); i++)
            {
                vec.addRow(input_, i);
            }

            if (ngrams.Count() > 0) {
                vec.mul(1.0F / ngrams.Count());
            }
        }

        public void saveVectors()
        {
            FileStream ofs = new FileStream(Path.Combine(System.Windows.Forms.Application.StartupPath, args_.output + ".vec"), FileMode.Create,
                System.IO.FileAccess.Write);

            BinaryWriter bw = new BinaryWriter(ofs);
            bw.Write(dict_.nwords());
            bw.Write(args_.dim);

            Vector vec = new Vector(args_.dim);
            for (int i = 0; i < dict_.nwords(); i++)
            {
                string word = dict_.getWord(i);
                getVector(vec, word);

                bw.Write(word);

                bw.Write(vec.m_);
                foreach (var vv in vec.data_)
                    bw.Write(vv);
            }
            bw.Close();
            ofs.Close();
        }

        public void saveOutput()
        {
            FileStream ofs = new FileStream(Path.Combine(System.Windows.Forms.Application.StartupPath, args_.output + ".output"), FileMode.Create,
                System.IO.FileAccess.Write);

            BinaryWriter bw = new BinaryWriter(ofs);
            bw.Write(dict_.nwords());
            bw.Write(args_.dim);

            Vector vec = new Vector(args_.dim);
            for (int i = 0; i < dict_.nwords(); i++)
            {
                string word = dict_.getWord(i);
                vec.zero();
                vec.addRow(output_, i);

                bw.Write(word);

                bw.Write(vec.m_);
                foreach (var vv in vec.data_)
                    bw.Write(vv);
            }
            bw.Close();
            ofs.Close();
        }


        public bool checkModel(BinaryReader inStream)
        {
            int magic;
            int version;
            magic = inStream.ReadInt32();
            if (magic != FASTTEXT_FILEFORMAT_MAGIC_INT32)
            {
                return false;
            }
            version = inStream.ReadInt32();
            if (version != FASTTEXT_VERSION)
            {
                return false;
            }

            return true;
        }
        public void signModel(BinaryWriter outStream)
        {
            int magic = FASTTEXT_FILEFORMAT_MAGIC_INT32;
            int version = FASTTEXT_VERSION;
            outStream.Write(magic);
            outStream.Write(version);
        }

        public void saveModel()
        {
            string fn = args_.output;
            if (quant_)
            {
                fn += ".ftz";
            }
            else
            {
                fn += ".bin";
            }
            FileStream ofs = new FileStream(Path.Combine(System.Windows.Forms.Application.StartupPath, fn + ".output"), FileMode.Create,
                            System.IO.FileAccess.Write);
            BinaryWriter bw = new BinaryWriter(ofs);

            signModel(bw);
            args_.save(bw);
            dict_.save(bw);

            bw.Write(quant_);
            if (quant_)
            {
                qinput_.save(ofs);
            }
            else
            {
                input_.save(ofs);
            }

            bw.Write(args_.qout);
            if (quant_ && args_.qout)
            {
                qoutput_.save(bw);
            }
            else
            {
                output_.save(bw);
            }

            bw.Close();
            ofs.Close();
        }

        public void loadModel(string filename)
        {
            var ifs = new FileStream(filename, FileMode.Open, FileAccess.Read);

            loadModel(new BinaryReader(ifs));
            ifs.Close();
        }

        public void loadModel(BinaryReader inStream)
        {
            args_ = new Args();
            dict_ = new Dictionary(args_);
            input_ = new Matrix();
            output_ = new Matrix();
            args_.load(inStream);
            dict_.load(inStream);
            input_.load(inStream);
            output_.load(inStream);
            model_ = new Model(input_, output_, args_, 0);
            if (args_.model == model_name.sup)
            {
                model_.setTargetCounts(dict_.getCounts(entry_type.label));
            }
            else
            {
                model_.setTargetCounts(dict_.getCounts(entry_type.word));
            }
        }

        public void printInfo(float progress, float loss)
        {
            float t = float(clock() - start) / CLOCKS_PER_SEC;
            float wst = float(tokenCount) / t;
            float lr = args_.lr * (1.0 - progress);
            int eta = t / progress * (1 - progress) / args_.thread;
            int etah = eta / 3600;
            int etam = (eta - etah * 3600) / 60;
            std::cerr << std::@fixed;
            std::cerr << "\rProgress: " << std::setprecision(1) << 100 * progress << "%";
            std::cerr << "  words/sec/thread: " << std::setprecision(0) << wst;
            std::cerr << "  lr: " << std::setprecision(6) << lr;
            std::cerr << "  loss: " << std::setprecision(6) << loss;
            std::cerr << "  eta: " << etah << "h" << etam << "m ";
            std::cerr << std::flush;
        }

        public List<int> selectEmbeddings(int cutoff)
        {
            Vector norms = new Vector(input_.m_);
            input_.l2NormRow(norms);
            List<int> idx = new List<int>(input_.m_, 0);
            std::iota(idx.GetEnumerator(), idx.end(), 0);
            var eosid = dict_.getId(Dictionary.EOS);
            //C++ TO C# CONVERTER TODO TASK: Only lambda expressions having all locals passed by reference can be converted to C#:
            //ORIGINAL LINE: std::sort(idx.begin(), idx.end(), [&norms, eosid] (uint i1, uint i2)
            //C++ TO C# CONVERTER TODO TASK: The 'Compare' parameter of std::sort produces a boolean value, while the .NET Comparison parameter produces a tri-state result:
            idx.Sort((uint i1, uint i2) =>
            {
                return eosid == i1 || (eosid != i2 && norms[i1] > norms[i2]);
            });
            //C++ TO C# CONVERTER TODO TASK: There is no direct equivalent to the STL vector 'erase' method in C#:
            idx.erase(idx.GetEnumerator() + cutoff, idx.end());
            return idx;
        }
        public void quantize(Args qargs)
        {
            if (qargs.output.empty())
            {
                std::cerr << "No model provided!" << std::endl;
                Environment.Exit(1);
            }
            loadModel(qargs.output + ".bin");

            args_.input = qargs.input;
            args_.qout = qargs.qout;
            args_.output = qargs.output;


            if (qargs.cutoff > 0 && qargs.cutoff < input_.m_)
            {
                var idx = selectEmbeddings(qargs.cutoff);
                dict_.prune(idx);
                Matrix ninput = new Matrix(idx.size(), args_.dim);
                for (var i = 0; i < idx.size(); i++)
                {
                    for (var j = 0; j < args_.dim; j++)
                    {
                        ninput.at(i, j) = input_.at(idx[i], j);
                    }
                }
                input_ = ninput;
                if (qargs.retrain)
                {
                    args_.epoch = qargs.epoch;
                    args_.lr = qargs.lr;
                    args_.thread = qargs.thread;
                    args_.verbose = qargs.verbose;
                    tokenCount = 0;
                    List<std::thread> threads = new List<std::thread>();
                    for (int i = 0; i < args_.thread; i++)
                    {
                        //C++ TO C# CONVERTER TODO TASK: Only lambda expressions having all locals passed by reference can be converted to C#:
                        //ORIGINAL LINE: threads.push_back(std::thread([=]()
                        threads.Add(std::thread(() =>
                        {
                            trainThread(i);
                        }));
                    }
                    foreach (std::thread it in threads)
                    {
                        it.join();
                    }
                }
            }

            qinput_ = new QMatrix(*input_, qargs.dsub, qargs.qnorm);

            if (args_.qout)
            {
                qoutput_ = new QMatrix(*output_, 2, qargs.qnorm);
            }

            quant_ = true;
            saveModel();
        }

        public void supervised(Model model, float lr, List<int> line, List<int> labels)
        {
            if (labels.Count == 0 || line.Count == 0)
            {
                return;
            }
            std::uniform_int_distribution<> uniform = new std::uniform_int_distribution<>(0, labels.Count - 1);
            int i = uniform(model.rng);
            model.update(line, labels[i], lr);
        }
        public void cbow(Model model, float lr, List<int> line)
        {
            List<int> bow = new List<int>();
            std::uniform_int_distribution<> uniform = new std::uniform_int_distribution<>(1, args_.ws);
            for (int w = 0; w < line.Count; w++)
            {
                int boundary = uniform(model.rng);
                bow.Clear();
                for (int c = -boundary; c <= boundary; c++)
                {
                    if (c != 0 && w + c >= 0 && w + c < line.Count)
                    {
                        List<int> ngrams = dict_.getNgrams(line[w + c]);
                        //C++ TO C# CONVERTER TODO TASK: There is no direct equivalent to the STL vector 'insert' method in C#:
                        bow.insert(bow.end(), ngrams.cbegin(), ngrams.cend());
                    }
                }
                model.update(bow, line[w], lr);
            }
        }

        public void skipgram(Model model, float lr, List<int> line)
        {
            std::uniform_int_distribution<> uniform = new std::uniform_int_distribution<>(1, args_.ws);
            for (int w = 0; w < line.Count; w++)
            {
                int boundary = uniform(model.rng);
                List<int> ngrams = dict_.getNgrams(line[w]);
                for (int c = -boundary; c <= boundary; c++)
                {
                    if (c != 0 && w + c >= 0 && w + c < line.Count)
                    {
                        model.update(ngrams, line[w + c], lr);
                    }
                }
            }
        }
        public void test(std::istream in, int k)
        {
            int nexamples = 0;
            int nlabels = 0;
            double precision = 0.0;
            List<int> line = new List<int>();
            List<int> labels = new List<int>();

            while (in.peek() != EOF)
	  {
                dict_.getLine(in, line, labels, model_.rng);
                if (labels.Count > 0 && line.Count > 0)
                {
                    List<System.Tuple<float, int>> modelPredictions = new List<System.Tuple<float, int>>();
                    model_.predict(line, k, modelPredictions);
                    for (var it = modelPredictions.cbegin(); it != modelPredictions.cend(); it++)
                    {
                        if (labels.Contains(it.second))
                        {
                            precision += 1.0;
                        }
                    }
                    nexamples++;
                    nlabels += labels.Count;
                }
            }
            Console.Write("N");
            Console.Write("\t");
            Console.Write(nexamples);
            Console.Write("\n");
            Console.Write("{0:3}", "P@");
            Console.Write("{0:3}", k);
            Console.Write("{0:3}", "\t");
            Console.Write("{0:3}", precision / (k * nexamples));
            Console.Write("{0:3}", "\n");
            Console.Write("{0:3}", "R@");
            Console.Write("{0:3}", k);
            Console.Write("{0:3}", "\t");
            Console.Write("{0:3}", precision / nlabels);
            Console.Write("{0:3}", "\n");
            std::cerr << "Number of examples: " << nexamples << std::endl;
        }


        public void predict(std::istream in, int k, List<System.Tuple<float, string>> predictions)
        {
            List<int> words = new List<int>();
            List<int> labels = new List<int>();
            dict_.getLine(in, words, labels, model_.rng);
            if (words.Count == 0)
            {
                return;
            }
            Vector hidden = new Vector(args_.dim);
            Vector output = new Vector(dict_.nlabels());
            List<System.Tuple<float, int>> modelPredictions = new List<System.Tuple<float, int>>();
            model_.predict(words, k, modelPredictions, hidden, output);
            predictions.Clear();
            for (var it = modelPredictions.cbegin(); it != modelPredictions.cend(); it++)
            {
                predictions.Add(System.Tuple.Create(it.first, dict_.getLabel(it.second)));
            }
        }
        public void predict(std::istream in, int k, bool print_prob)
        {
            List<System.Tuple<float, string>> predictions = new List<System.Tuple<float, string>>();
            while (in.peek() != EOF)
	  {
                predict(in, k, predictions);
                if (predictions.Count == 0)
                {
                    Console.Write("\n");
                    continue;
                }
                for (var it = predictions.cbegin(); it != predictions.cend(); it++)
                {
                    if (it != predictions.cbegin())
                    {
                        Console.Write(" ");
                    }
                    Console.Write(it.second);
                    if (print_prob)
                    {
                        Console.Write(" ");
                        Console.Write(Math.Exp(it.first));
                    }
                }
                Console.Write("\n");
            }
        }
        public void wordVectors()
        {
            string word;
            Vector vec = new Vector(args_.dim);
            while ((word = ConsoleInput.ReadToWhiteSpace(true)).Length > 0)
            {
                getVector(vec, word);
                Console.Write(word);
                Console.Write(" ");
                Console.Write(vec);
                Console.Write("\n");
            }
        }

        public void sentenceVectors()
        {
            Vector vec = new Vector(args_.dim);
            string sentence;
            Vector svec = new Vector(args_.dim);
            string word;
            while (sentence = Console.ReadLine())
            {
                std::istringstream iss = new std::istringstream(sentence);
                svec.zero();
                int count = 0;
                while (iss >> word != 0)
                {
                    getVector(vec, word);
                    vec.mul(1.0 / vec.norm());
                    svec.addVector(vec);
                    count++;
                }
                svec.mul(1.0 / count);
                Console.Write(sentence);
                Console.Write(" ");
                Console.Write(svec);
                Console.Write("\n");
            }
        }
        public void ngramVectors(string word)
        {
            List<int> ngrams = new List<int>();
            List<string> substrings = new List<string>();
            Vector vec = new Vector(args_.dim);
            dict_.getNgrams(word, ngrams, substrings);
            for (int i = 0; i < ngrams.Count; i++)
            {
                vec.zero();
                if (ngrams[i] >= 0)
                {
                    vec.addRow(*input_, ngrams[i]);
                }
                Console.Write(substrings[i]);
                Console.Write(" ");
                Console.Write(vec);
                Console.Write("\n");
            }
        }
        public void textVectors()
        {
            List<int> line = new List<int>();
            List<int> labels = new List<int>();
            Vector vec = new Vector(args_.dim);
            while (std::cin.peek() != EOF)
            {
                dict_.getLine(std::cin, line, labels, model_.rng);
                vec.zero();
                for (var it = line.cbegin(); it != line.cend(); ++it)
                {
                    vec.addRow(*input_, *it);
                }
                if (line.Count > 0)
                {
                    vec.mul(1.0 / line.Count);
                }
                Console.Write(vec);
                Console.Write("\n");
            }
        }
        public void printWordVectors()
        {
            wordVectors();
        }
        public void printSentenceVectors()
        {
            if (args_.model == model_name.sup)
            {
                textVectors();
            }
            else
            {
                sentenceVectors();
            }
        }

        public void precomputeWordVectors(Matrix wordVectors)
        {
            Vector vec = new Vector(args_.dim);
            wordVectors.zero();
            Console.Write("Pre-computing word vectors...");
            for (int i = 0; i < dict_.nwords(); i++)
            {
                string word = dict_.getWord(i);
                getVector(vec, word);
                float norm = vec.norm();
                wordVectors.addRow(vec, i, 1.0 / norm);
            }
            Console.Write(" done.");
            Console.Write("\n");
        }
        public void findNN(Matrix wordVectors, Vector queryVec, int k, SortedSet<string> banSet)
        {
            float queryNorm = queryVec.norm();
            if (Math.Abs(queryNorm) < 1e-8)
            {
                queryNorm = 1;
            }
            std::priority_queue<System.Tuple<float, string>> heap = new std::priority_queue<System.Tuple<float, string>>();
            Vector vec = new Vector(args_.dim);
            for (int i = 0; i < dict_.nwords(); i++)
            {
                string word = dict_.getWord(i);
                float dp = wordVectors.dotRow(queryVec, i);
                heap.push(System.Tuple.Create(dp / queryNorm, word));
            }
            int i = 0;
            while (i < k && heap.size() > 0)
            {
                var it = banSet.find(heap.top().second);
                if (it == banSet.end())
                {
                    Console.Write(heap.top().second);
                    Console.Write(" ");
                    Console.Write(heap.top().first);
                    Console.Write("\n");
                    i++;
                }
                heap.pop();
            }
        }
        public void nn(int k)
        {
            string queryWord;
            Vector queryVec = new Vector(args_.dim);
            Matrix wordVectors = new Matrix(dict_.nwords(), args_.dim);
            precomputeWordVectors(wordVectors);
            SortedSet<string> banSet = new SortedSet<string>();
            Console.Write("Query word? ");
            while ((queryWord = ConsoleInput.ReadToWhiteSpace(true)).Length > 0)
            {
                banSet.Clear();
                banSet.Add(queryWord);
                getVector(queryVec, queryWord);
                findNN(wordVectors, queryVec, k, banSet);
                Console.Write("Query word? ");
            }
        }

        public void analogies(int k)
        {
            string word;
            Vector buffer = new Vector(args_.dim);
            Vector query = new Vector(args_.dim);
            Matrix wordVectors = new Matrix(dict_.nwords(), args_.dim);
            precomputeWordVectors(wordVectors);
            SortedSet<string> banSet = new SortedSet<string>();
            Console.Write("Query triplet (A - B + C)? ");
            while (true)
            {
                banSet.Clear();
                query.zero();
                word = ConsoleInput.ReadToWhiteSpace(true);
                banSet.Add(word);
                getVector(buffer, word);
                query.addVector(buffer, 1.0);
                word = ConsoleInput.ReadToWhiteSpace(true);
                banSet.Add(word);
                getVector(buffer, word);
                query.addVector(buffer, -1.0);
                word = ConsoleInput.ReadToWhiteSpace(true);
                banSet.Add(word);
                getVector(buffer, word);
                query.addVector(buffer, 1.0);

                findNN(wordVectors, query, k, banSet);
                Console.Write("Query triplet (A - B + C)? ");
            }
        }
        public void trainThread(int threadId)
        {
            std::ifstream ifs = new std::ifstream(args_.input);
            utils.seek(ifs, threadId * utils.size(ifs) / args_.thread);

            Model model = new Model(input_, output_, args_, threadId);
            if (args_.model == model_name.sup)
            {
                model.setTargetCounts(dict_.getCounts(entry_type.label));
            }
            else
            {
                model.setTargetCounts(dict_.getCounts(entry_type.word));
            }

            long ntokens = dict_.ntokens();
            long localTokenCount = 0;
            List<int> line = new List<int>();
            List<int> labels = new List<int>();
            while (tokenCount < args_.epoch * ntokens)
            {
                float progress = float(tokenCount) / (args_.epoch * ntokens);
                float lr = args_.lr * (1.0 - progress);
                localTokenCount += dict_.getLine(ifs, line, labels, model.rng);
                if (args_.model == model_name.sup)
                {
                    supervised(model, lr, line, labels);
                }
                else if (args_.model == model_name.cbow)
                {
                    cbow(model, lr, line);
                }
                else if (args_.model == model_name.sg)
                {
                    skipgram(model, lr, line);
                }
                if (localTokenCount > args_.lrUpdateRate)
                {
                    tokenCount += localTokenCount;
                    localTokenCount = 0;
                    if (threadId == 0 && args_.verbose > 1)
                    {
                        printInfo(progress, model.getLoss());
                    }
                }
            }
            if (threadId == 0 && args_.verbose > 0)
            {
                printInfo(1.0, model.getLoss());
                std::cerr << std::endl;
            }
            ifs.close();
        }

        public void loadVectors(string filename)
        {
            std::ifstream in = new std::ifstream(filename);
            List<string> words = new List<string>();
            Matrix mat; // temp. matrix for pretrained vectors
            long n;
            long dim;
            if (!in.is_open())
	  {
                std::cerr << "Pretrained vectors file cannot be opened!" << std::endl;
                Environment.Exit(1);
            }
	  in >> (int)n >> (int)dim;
            if (dim != args_.dim)
            {
                std::cerr << "Dimension of pretrained vectors does not match -dim option" << std::endl;
                Environment.Exit(1);
            }
            mat = new Matrix(n, dim);
            for (uint i = 0; i < n; i++)
            {
                string word;
		in >> word;
                words.Add(word);
                dict_.add(word);
                for (uint j = 0; j < dim; j++)
                {
		  in >> mat.data_[i * dim + j];
                }
            }
	  in.close();

            dict_.threshold(1, 0);
            input_ = new Matrix(dict_.nwords() + args_.bucket, args_.dim);
            input_.uniform(1.0 / args_.dim);

            for (uint i = 0; i < n; i++)
            {
                int idx = dict_.getId(words[i]);
                if (idx < 0 || idx >= dict_.nwords())
                {
                    continue;
                }
                for (uint j = 0; j < dim; j++)
                {
                    input_.data_[idx * dim + j] = mat.data_[i * dim + j];
                }
            }
        }
        public void train(Args args)
        {
            args_ = args;
            dict_ = new Dictionary(args_);
            if (args_.input == "-")
            {
                // manage expectations
                std::cerr << "Cannot use stdin for training!" << std::endl;
                Environment.Exit(1);
            }
            std::ifstream ifs = new std::ifstream(args_.input);
            if (!ifs.is_open())
            {
                std::cerr << "Input file cannot be opened!" << std::endl;
                Environment.Exit(1);
            }
            dict_.readFromFile(ifs);
            ifs.close();

            if (args_.pretrainedVectors.size() != 0)
            {
                loadVectors(args_.pretrainedVectors);
            }
            else
            {
                input_ = new Matrix(dict_.nwords() + args_.bucket, args_.dim);
                input_.uniform(1.0 / args_.dim);
            }

            if (args_.model == model_name.sup)
            {
                output_ = new Matrix(dict_.nlabels(), args_.dim);
            }
            else
            {
                output_ = new Matrix(dict_.nwords(), args_.dim);
            }
            output_.zero();

            start = clock();
            tokenCount = 0;
            if (args_.thread > 1)
            {
                List<std::thread> threads = new List<std::thread>();
                for (int i = 0; i < args_.thread; i++)
                {
                    //C++ TO C# CONVERTER TODO TASK: Only lambda expressions having all locals passed by reference can be converted to C#:
                    //ORIGINAL LINE: threads.push_back(std::thread([=]()
                    threads.Add(std::thread(() =>
                    {
                        trainThread(i);
                    }));
                }
                foreach (std::thread it in threads)
                {
                    it.join();
                }
            }
            else
            {
                trainThread(0);
            }
            model_ = new Model(input_, output_, args_, 0);

            saveModel();
            if (args_.model != model_name.sup)
            {
                saveVectors();
                if (args_.saveOutput > 0)
                {
                    saveOutput();
                }
            }
        }
    }
}
