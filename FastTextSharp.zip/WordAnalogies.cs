﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastText
{
    /// <summary>
    /// 得られた単語ベクトルの質の評価：似た特徴点の探索
    /// </summary>
    public class WordAnalogies
    {
        float data_;

        string word;

        static Vector query = null;
        static SortedSet<string> banSet = new SortedSet<string>();

        static NN nn;
        static Vector buffer;

        public static void Init(Fasttext fastVec)
        {
            if (nn == null)
                nn = new NN(fastVec);
            else
            {
                if (nn.fasttext != fastVec)
                    throw new Exception("Fast2Vecはひとつだけでなくてはいけません");
            }

            buffer = new Vector(nn.fasttext.args_.dim);
            query = new Vector(nn.fasttext.args_.dim);
        }

        public WordAnalogies(string word2)
        {
            if (nn == null)
                throw new Exception("Initメソッドで先に初期化してください");

            word = word2;
        }

        #region operator
        public static WordAnalogies operator +(WordAnalogies word1, WordAnalogies word2)
        {

            return word1.Add(word2);
        }

        public static WordAnalogies operator -(WordAnalogies word1, WordAnalogies word2)
        {

            return word1.Subtract(word2);
        }

        WordAnalogies Subtract(WordAnalogies word2)
        {
            var sum = data_ - word2.data_;

            return ComputeAnalogies(word2, sum, -1.0F);
        }

        WordAnalogies Add(WordAnalogies word2)
        {
            var sum = data_ + word2.data_;

            return ComputeAnalogies(word2, sum, 1.0F);
        }

        WordAnalogies ComputeAnalogies(WordAnalogies word2,float sum ,float vector)
        {
            WordAnalogies temp = new WordAnalogies(word);
            temp.data_ = sum;

            buffer.zero();

            banSet.Add(word);
            nn.fasttext.getVector(buffer, word);
            query.addVector(buffer, vector);

            return temp;
        }
        #endregion operator

        public List<System.Tuple<float, string>> Answer(int count)
        {
            var answer = nn.findNN(nn.wordVectors, query, count, banSet);

            banSet.Clear();
            query.zero();

            return answer;
        }

        public List<System.Tuple<float, string>> NearestWords(int count)
        {
            return nn.NearestWords_NN(word, count);
        }
    }
}
