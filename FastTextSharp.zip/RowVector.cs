﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastText
{
    public class RowVector:Vector
    {
        public RowVector(string word, float[] vector):base(vector)
        {
            this.Word = word;
        }

        public RowVector(string word, Vector vector) : base(vector.data_)
        {
            this.Word = word;
        }

        public string Word { get; private set; }
    }
}
