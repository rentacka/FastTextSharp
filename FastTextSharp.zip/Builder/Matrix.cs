﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastText
{
    public class Matrix
    {
        internal Vector[] data_;

        public long Dim { get { return data_[0].Count(); } }

        public int Count()
        {
            return data_.Count();
        }

        void InitData(long count, long dim)
        {
            data_ = new Vector[count];
            for (int i=0;i< count; i++)
            {
                data_[i] = new Vector(dim);
            }
        }

        void InitData(Matrix other)
        {
            data_ = new Vector[other.Count()];
            for (long i = 0; i < Dim; i++)
            {
                data_[i] = other.data_[i];
            }
        }

        internal Matrix() {
            data_ = new Vector[0];
        }


        public Matrix(long count, long dim) {
            InitData(count,dim);
        }

        public Matrix(Matrix other) {
            InitData(other);
        }

        #region operator
        public static Matrix operator +(Matrix word1, Matrix word2)
        {

            return word1.Add(word2);
        }

        public Matrix Add(Matrix word2)
        {
            var sum = Matrix.Add(data_, word2.data_);

            Matrix temp = new Matrix();
            temp.data_ = sum;

            return temp;
        }

        internal static Vector[] Add(Vector[] value1, Vector[] value2)
        {
            var result = new Vector[value1.Count()];
            for (int i=0;i<value1.Count();i++)
            {
                var vec = value1[i]+ value2[i];
            }

            return result;
        }
        #endregion operator

        public void zero()
        {
            for (long i = 0; i < Count(); i++)
            {
                data_[i].zero();
            }
        }

        public void uniform(int a)
        {
            var round = new Random(Fasttext.Seed());

            for (long i = 0; i < Count(); i++)
            {
                for (long j = 0; j < Dim; j++)
                {
                    data_[i].data_[j] = round.Next(-a, a);
                }
            }
        }

        public void addRow(Vector vec, long i, float a)
        {
            Debug.Assert(i >= 0);
            Debug.Assert(i < Count());
            Debug.Assert(vec.Count() == Dim);
            for (long j = 0; j < Dim; j++)
            {
                data_[i].data_[j] += a * vec.data_[j];
            }
        }

        public long dotRow(Vector vec, long i)
        {
            Debug.Assert(i >= 0);
            Debug.Assert(i < Count());
            Debug.Assert(vec.Count() == Dim);
            float d = 0f;
            for (long j = 0; j < Dim; j++)
            {
                d += data_[i].data_[j] * vec.data_[j];
            }
            return (long)d;
        }

        public static Matrix CopyMatrix(Matrix mat)
        {
            Matrix temp = new Matrix(mat.Count(), mat.Dim);
            for (long i = 0; i < temp.Count(); i++)
            {
                for (long j = 0; j < temp.Dim; j++)
                {
                    temp.data_[i].data_[j] = mat.data_[i].data_[j];
                }
            }

            return temp;
        }

        public void save(BinaryWriter stream)
        {
            stream.Write(Count());
            stream.Write(Dim);

            foreach (var vec in data_)
                foreach (var bit in vec.data_)
                    stream.Write(bit);
        }

        public void load(BinaryReader stream)
        {
            var count_ = stream.ReadInt64();
            var dim_ = stream.ReadInt64();

            InitData(count_ , dim_);
            for (long i = 0; i < count_; i++)
            {
                for (long j = 0; j < count_; j++)
                {
                    var bit = stream.ReadInt64();
                    data_[i].data_[j] = bit;
                }
            }
        }

    }
}
