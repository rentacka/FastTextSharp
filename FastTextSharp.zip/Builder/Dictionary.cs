﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static FastText.Args;

namespace FastText
{
    internal class Dictionary
    {
        internal class VocubComparer : IComparer<VocubEntry>
        {
            public int Compare(VocubEntry x, VocubEntry y)
            {
                /*
                if (x.type != y.type)
                {
                    return (int)x.type + (int)y.type;
                }
                */

                return (int)(y.count - x.count);
            }
        }

        private const int MAX_VOCAB_SIZE = 30000000;
        private const int MAX_LINE_SIZE = 1024;

        public enum entry_type : sbyte
        {
            word = 0,
            label = 1
        }

        public class VocubEntry
        {
            public string word;
            /// <summary>
            /// 文章データ中のその単語がでてきた回数
            /// </summary>
            public long count;
            public entry_type type;
            public List<int> subword = new List<int>();

            public int CompareTo(VocubEntry other)
            {
                return (int)(this.count - other.count);
            }
        }

        private Args args_;
        internal List<long> word2int_;
        // word2int_はVocubEntryに含めることができる
        internal List<VocubEntry> vocabWords_ = new List<VocubEntry>();
        private double[] pdiscard_ = null;

        private int nwords_;
        private int nlabels_;
        private long ntokens_;

        private const string EOS = "</s>";
        private const string BOW = "<";
        private const string EOW = ">";

        public Dictionary(Args args)
        {
            args_ = args;
            nwords_ = 0;
            nlabels_ = 0;
            ntokens_ = 0;
            word2int_= new List<long>();
        }
        public int IndexOf(string w)
        {
            //var h = (int)hash(w);

            //var h = (int)(hash(w) % MAX_VOCAB_SIZE);
            /*
            while (word2int_[h] != -1 && vocabWords_[(int)word2int_[h]].word != w)
            {
                h = (h + 1) % MAX_VOCAB_SIZE;
            }
            */

            //return word2int_.IndexOf(h);

            int j = -1;
            foreach (var vocab in vocabWords_)
            {
                if (vocab.word == w)
                {
                    j++;

                    break;
                }
            }

            return j;
        }

        public void add(string w)
        {
            if (w.Count() > 0)
            {
                int idx = IndexOf(w);
                ntokens_++;
                if (idx == -1)
                {
                    VocubEntry e = new VocubEntry();
                    e.word = w;
                    e.count = 1;
                    e.type = (w.IndexOf(args_.label) == 0) ? entry_type.label : entry_type.word;
                    vocabWords_.Add(e);
                    word2int_.Add(hash(w));

                    // サブワード追加
                    var subwords = Ngram.GetNGrams(args_.wordNgrams, w);
                    foreach (var subword in subwords)
                    {
                        word2int_.Add(hash(subword));

                        /*
                        int subIdx = IndexOf(w);
                        if (subIdx == -1)
                        {
                            VocubEntry subE = new VocubEntry();
                            subE.word = w;
                            subE.count = 1;
                            subE.type = (w.IndexOf(args_.label) == 0) ? entry_type.label : entry_type.word;
                            vocabWords_.Add(subE);
                            word2int_.Add(hash(subword));
                        }
                        else
                        {
                            vocabWords_[subIdx].count++;
                        }
                        */
                    }
                }
                else
                {
                    vocabWords_[idx].count++;
                }
            }
        }

        public long nwords()
        {
            return nwords_;
        }

        public int nlabels()
        {
            return nlabels_;
        }

        public long ntokens()
        {
            return ntokens_;
        }

        #region getNgrams
        public List<int> getNgrams(int idx)
        {
            Debug.Assert(idx >= 0);
            Debug.Assert(idx < nwords_);
            return vocabWords_[idx].subword;
        }

        public List<int> getNgrams(string word)
        {
            int i = IndexOf(word);
            if (i >= 0)
            {
                return getNgrams(i);
            }
            List<int> ngrams = new List<int>();
            computeNgrams(word, ngrams);
            return ngrams;
        }

        // 参照なし
        void getNgrams(string word, List<int> ngrams, List<string> substrings)
        {
            int i = IndexOf(word);

            ngrams.Clear();
            substrings.Clear();
            if (i >= 0)
            {
                ngrams.Add(i);
                substrings.Add(vocabWords_[i].word);
            }
            else
            {
                ngrams.Add(-1);
                substrings.Add(word);
            }
            computeNgrams(word, ngrams, substrings);
        }
        #endregion getNgrams

        public bool discard(int id, double rand)
        {
            Debug.Assert(id >= 0);
            Debug.Assert(id < nwords_);
            if (args_.modelType == model_name.sup)
            {
                return false;
            }
            return rand > pdiscard_[id];
        }

        public entry_type getType(int id)
        {
            Debug.Assert(id >= 0);
            Debug.Assert(id < word2int_.Count);
            return vocabWords_[id].type;
        }
        public entry_type getType(string w)
        {
            return (w.IndexOf(args_.label) == 0) ? entry_type.label : entry_type.word;
        }

        internal string getWord(int id)
        {
            Debug.Assert(id >= 0);
            Debug.Assert(id < word2int_.Count);

            return vocabWords_[id].word;
        }

        long hash(string str)
        {
            // ハッシュの計算方式はじつのところ何でもいい
            // 単語も短いからそんなに長さもきにしなくていい
            long h = 2166136261;
            for (int i = 0; i < str.Length; i++)
            {
                h = h ^ (long)str[i];
                h = h * 16777619;
            }
            /*
            long h = 1;
            for (int i = 0; i < str.Length; i++)
            {
                h = h * (long)str[i];
            }
            */

            return h;
        }

        #region computeNgrams
        public void computeNgrams(string word, List<int> ngrams, List<string> substrings)
        {
            if (word.Length >= args_.wordNgrams)
            {
                var splitStrs = Ngram.GetNGrams(args_.wordNgrams, word);

                int i = 0;
                foreach (var str in splitStrs)
                {
                    ngrams.Add(nwords_ + i);
                    substrings.Add(str);

                    i++;
                }
            }
        }

        public void computeNgrams(string word, List<int> ngrams)
        {
            if (word.Length >= args_.wordNgrams)
            {
                var splitStrs = Ngram.GetNGrams(args_.wordNgrams, word);

                int i = 0;
                foreach (var str in splitStrs)
                {
                    ngrams.Add(nwords_ + i);

                    i++;
                }
            }
        }
        #endregion computeNgrams

        #region Read
        public void initNgrams()
        {
            for (int i = 0; i < vocabWords_.Count; i++)
            {
                string word = vocabWords_[i].word;

                for (int j = 0; j < args_.wordNgrams; j++)
                {
                    //vocabWords_[i].subwordIdxs.Add(j);
                    computeNgrams(word, vocabWords_[i].subword);
                }
            }
        }

        public void readFromText(string text, long minThreshold = 1)
        {
            var substance = text.Split(" ".ToCharArray());
            foreach (var word in substance)
            {
                add(word);
                if (ntokens_ % 1000000 == 0 && args_.verbose > 1)
                {
                    Console.Write("\rRead ");
                    Console.Write(ntokens_ / 1000000);
                    Console.Write("M words");
                }

                if (word2int_.Count > 0.75 * MAX_VOCAB_SIZE)
                {
                    minThreshold++;
                    threshold(minThreshold, minThreshold);
                }
            }
            threshold(args_.minCount, args_.minCountLabel);

            initTableDiscard();
            initNgrams();
            if (args_.verbose > 0)
            {
                Console.Write("\rRead ");
                Console.Write(ntokens_ / 1000000);
                Console.Write("M words");
                Console.Write("\n");
                Console.Write("Number of words:  ");
                Console.Write(nwords_);
                Console.Write("\n");
                Console.Write("Number of labels: ");
                Console.Write(nlabels_);
                Console.Write("\n");
            }
            if (word2int_.Count == 0)
            {
                Environment.Exit(1);
            }
        }

        public void readFromFile(FileStream inStream)
        {
            var sr = new StreamReader(inStream, Encoding.GetEncoding(932));

            readFromText(sr.ReadToEnd());
        }

        /// <summary>
        /// vocabWords_とword2int_のつかってない配列をメモリ解放
        /// </summary>
        /// <param name="t"></param>
        /// <param name="tl"></param>
        public void threshold(long t, long tl)
        {
            vocabWords_.Sort(0, vocabWords_.Count,new VocubComparer());

            /*
            // shrink_to_fit:キャパシティを現在のサイズの値にし、余分なメモリを解放
            for (int i=0; i<vocabWords_.Count;i++)
            {
                var e = vocabWords_[i];
                if ((e.type == entry_type.word && e.count < t) || (e.type == entry_type.label && e.count < tl))
                    vocabWords_.Remove(e);
            }
            */

            //nwords_ = 0;
            //nlabels_ = 0;
            /*
            for (int i = 0; i < MAX_VOCAB_SIZE; i++)
            {
                word2int_[i] = -1;
            }
            */
            for (int i = 0; i< vocabWords_.Count; i++)
            {
                var it = vocabWords_[i];
                var h = hash(it.word);
                word2int_[i] = h;
                if (it.type == entry_type.word)
                {
                    nwords_++;
                }
                if (it.type == entry_type.label)
                {
                    nlabels_++;
                }
            }
        }

        public void initTableDiscard()
        {
            Array.Resize(ref pdiscard_, vocabWords_.Count);

            for (int i = 0; i < vocabWords_.Count; i++)
            {
                var f = ((float)vocabWords_[i].count) / ((float)ntokens_);
                pdiscard_[i] = Math.Sqrt((double)args_.t / (double)f) + (double)args_.t / (double)f;
            }
        }
        #endregion Read

        public List<long> getCounts(entry_type type)
        {
            List<long> counts = new List<long>();
            foreach (var w in vocabWords_)
            {
                if (w.type == type)
                {
                    counts.Add(w.count);
                }
            }
            return counts;
        }

        // TODO:おかしな計算
        public void addNgrams(List<int> line, List<int> hashes, int n)
        {
            for (int i = 0; i < hashes.Count; i++)
            {
                ulong h = (ulong)hashes[i];
                for (int j = i + 1; j < hashes.Count && j < i + n; j++)
                {
                    h = h * 116049371 + (ulong)hashes[j];
                    var id = (int)(h % (ulong)args_.bucket);

                    // Vocabより後ろに追加（使用してない空きやからやとは思う
                    line.Add(nwords_ + id);
                }
            }
        }

        int getLine(string lineText, List<int> words,List<int> word_hashes,List<int> labels, int rng)
        {
            var round = new Random(rng);
            var uniform = round.NextDouble();
            int ntokens = 0;
            words.Clear();
            labels.Clear();

            var substance = lineText.Split(" ".ToCharArray());

            foreach (var token in substance)
            {
                int wid = IndexOf(token);
                if (wid < 0)
                {
                    entry_type tokenType = getType(token);
                    if (tokenType == entry_type.word)
                        word_hashes.Add((int)hash(token));
                    continue;
                }

                entry_type type = getType(wid);
                ntokens++;
                if (type == entry_type.word && !discard(wid, uniform))
                {
                    words.Add(wid);
                    word_hashes.Add((int)hash(token));
                }
                if (type == entry_type.label)
                {
                    labels.Add(wid - nwords_);
                }

                // 行の端
                /*
                if (token == EOS)
                {
                    break;
                }
                */

                if (words.Count > MAX_LINE_SIZE && args_.modelType != model_name.sup)
                {
                    break;
                }
            }
            return ntokens;
        }

        int getLine(StreamReader inStream, List<int> words, List<int> word_hashes, List<int> labels, int rng)
        {
            var substance = inStream.ReadLine();

            return getLine(substance, words, word_hashes, labels, rng); ;
        }

        public int getLine(StreamReader inStream, List<int> words, List<int> labels, int rng)
        {
            var text = inStream.ReadLine();
            int ntokens = getLine(text, words, labels, rng);

            return ntokens;
        }

        public int getLine(string lineText, List<int> words, List<int> labels, int rng)
        {
            List<int> word_hashes = new List<int>();
            int ntokens = getLine(lineText, words, word_hashes, labels, rng);
            if (args_.modelType == model_name.sup)
            {
                addNgrams(words, word_hashes, args_.wordNgrams);
            }
            return ntokens;
        }

        public void save(BinaryWriter outStream )
        {
            outStream.Write(word2int_.Count);
            outStream.Write(nwords_);
            outStream.Write(nlabels_);
            outStream.Write(ntokens_);
            for (int i = 0; i < vocabWords_.Count; i++)
            {
                VocubEntry e = vocabWords_[i];
                outStream.Write(e.word);

                outStream.Write(e.count);
                outStream.Write((int)e.type);
            }
        }

        public void load(BinaryReader inStream)
        {
            vocabWords_.Clear();
            for (int i = 0; i < MAX_VOCAB_SIZE; i++)
            {
                word2int_[i] = -1;
            }

            var size_ = inStream.ReadInt32();
            nwords_ = inStream.ReadInt32();
            nlabels_ = inStream.ReadInt32();
            ntokens_ = inStream.ReadInt32();
            for (int i = 0; i < size_; i++)
            {
                VocubEntry e = new VocubEntry();
                e.word = inStream.ReadString();

                e.count = inStream.ReadInt32();
                e.type = (entry_type)inStream.ReadInt32();

                vocabWords_.Add(e);
                word2int_[IndexOf(e.word)] = i;
            }

            initTableDiscard();
            initNgrams();
        }
    }
}