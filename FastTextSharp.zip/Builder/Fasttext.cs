﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FastText
{
    public class Fasttext
    {
        public const int FASTTEXT_VERSION = 11; // Version 1a
        public const int FASTTEXT_FILEFORMAT_MAGIC_INT32 = 793712314;

        internal Args args_;
        internal Dictionary dict_;
        /// <summary>
        /// ランダムな-0～1.0のテーブル
        /// </summary>
        internal Matrix rndMat;
        internal Matrix outdicMat;
        internal Model model_;
        long tokenCount = 0;

        internal void getVector(Vector vec, string word)
        {
            var idx = dict_.IndexOf(word);

            if (idx == -1)
                vec = new Vector(0);
            else
                vec = new Vector(outdicMat.data_[idx].data_);
        }

        #region saveModel
        public void saveModel()
        {
            /*
  if (quant_) {
	  // Quentation用の保存拡張子
    fn += ".ftz";
  } else {
    fn += ".bin";
  }             
             */
            FileStream ofs = new FileStream(Path.Combine(System.Windows.Forms.Application.StartupPath, args_.outputName + ".bin"), FileMode.Create,
                            System.IO.FileAccess.Write);
            BinaryWriter bw = new BinaryWriter(ofs);

            args_.save(bw);
            dict_.save(bw);
            /*
  ofs.write((char*)&(quant_), sizeof(bool));
  if (quant_) {
    qinput_->save(ofs);
  } else {
    input_->save(ofs);
  }

  ofs.write((char*)&(args_->qout), sizeof(bool));
  if (quant_ && args_->qout) {
    qoutput_->save(ofs);
  } else {
    output_->save(ofs);
  }
  */
            rndMat.save(bw);
            outdicMat.save(bw);

            bw.Close();
            ofs.Close();
        }
        #endregion saveModel

        #region loadModel
        public void loadModel(string filename)
        {
            var ifs = new FileStream(filename, FileMode.Open, FileAccess.Read);

            loadModel(new BinaryReader(ifs));
            ifs.Close();
        }

        public void loadModel(BinaryReader inStream)
        {
            args_ = new Args();
            dict_ = new Dictionary(args_);
            rndMat = new Matrix();
            outdicMat = new Matrix();

            args_.load(inStream);
            dict_.load(inStream);
            /*
  bool quant_input;
  in.read((char*) &quant_input, sizeof(bool));
  if (quant_input) {
    quant_ = true;
    qinput_->load(in);
  } else {
    input_->load(in);
  }

  in.read((char*) &args_->qout, sizeof(bool));
  if (quant_ && args_->qout) {
    qoutput_->load(in);
  } else {
    output_->load(in);
  }

  model_ = std::make_shared<Model>(input_, output_, args_, 0);
  model_->quant_ = quant_;
  model_->setQuantizePointer(qinput_, qoutput_, args_->qout);
  */
            rndMat.load(inStream);
            outdicMat.load(inStream);

            model_ = new Model(rndMat, outdicMat, args_, Fasttext.Seed());
            if (args_.modelType == Args.model_name.sup)
            {
                model_.setTargetCounts(dict_.getCounts(Dictionary.entry_type.label));
            }
            else
            {
                model_.setTargetCounts(dict_.getCounts(Dictionary.entry_type.word));
            }
        }
        #endregion loadModel
        
        public void printInfo(float progress, float loss)
        {
            /*
            float t = float(clock() - start) / CLOCKS_PER_SEC;
            float wst = float(tokenCount) / t;
            float lr = args_.lr * (1.0 - progress);
            int eta = t / progress * (1 - progress) / args_.thread;
            int etah = eta / 3600;
            int etam = (eta - etah * 3600) / 60;
            std::cerr << std::@fixed;
            std::cerr << "\rProgress: " << std::setprecision(1) << 100 * progress << "%";
            std::cerr << "  words/sec/thread: " << std::setprecision(0) << wst;
            std::cerr << "  lr: " << std::setprecision(6) << lr;
            std::cerr << "  loss: " << std::setprecision(6) << loss;
            std::cerr << "  eta: " << etah << "h" << etam << "m ";
            std::cerr << std::flush;
            */
        }

        // quantize()で呼ばれる
        //public List<int> selectEmbeddings(int cutoff)

        // public void quantize()

        #region command == "skipgram" || command == "cbow" || command == "supervised"
        public void supervised(Model model, float lr, List<int> line, List<int> labels)
        {
            if (labels.Count == 0 || line.Count == 0)
            {
                return;
            }
            var rng = model.rng;
            var iUniform = rng.Next(labels.Count - 1);
            model.updateCorpas(line, labels[iUniform], lr);
        }

        public void cbow(Model model, float lr, List<int> line)
        {
            List<int> bow = new List<int>();


            for (int w = 0; w < line.Count; w++)
            {
                int boundary = model.rng.Next(1, args_.ws);
                bow.Clear();
                for (int c = -boundary; c <= boundary; c++)
                {
                    if (c != 0 && w + c >= 0 && w + c < line.Count)
                    {
                        List<int> ngrams = dict_.getNgrams(line[w + c]);
                        //bow.Insert(bow.end(), ngrams.cbegin(), ngrams.cend());
                        bow.AddRange(ngrams);
                    }
                }
                model.updateCorpas(bow, line[w], lr);
            }

            /*
            for (int w = 0; w < line.Count; w++)
            {
                bow.Clear();

                // ランダムにNgramを追加
                int boundary = model.rng.Next(0, (line.Count - 1) - args_.ws);
                List<int> ngrams = dict_.getNgramsIdx(line[boundary]);
                //bow.Insert(bow.end(), ngrams.cbegin(), ngrams.cend());
                bow.AddRange(ngrams);

                model.updateCorpas(bow, line[w], lr);
            }
            */
        }

        public void skipgram(Model model, float lr, List<int> line)
        {
            for (int w = 0; w < line.Count; w++)
            {
                int boundary = model.rng.Next(1, args_.ws);
                List<int> ngrams = dict_.getNgrams(line[w]);
                for (int c = -boundary; c <= boundary; c++)
                {
                    if (c != 0 && w + c >= 0 && w + c < line.Count)
                    {
                        model.updateCorpas(ngrams, line[w + c], lr);
                    }
                }
            }

            /*
            for (int w = 0; w < line.Count; w++)
            {
                // ランダムにNgramを追加
                int boundary = model.rng.Next(0, (line.Count - 1) - args_.ws);
                List<int> ngrams = dict_.getNgramsIdx(line[boundary]);

                model.updateCorpas(ngrams, line[w], lr);
            }
            */
        }
        #endregion command == "skipgram" || command == "cbow" || command == "supervised"

        #region test
        public void test(StreamReader inStream, int k)
        {
            int nexamples = 0;
            int nlabels = 0;
            double precision = 0.0;
            List<int> line = new List<int>();
            List<int> labels = new List<int>();

            while (inStream.Peek() != -1)
            {
                dict_.getLine(inStream, line, labels, model_.rng.Next());
                if (labels.Count > 0 && line.Count > 0)
                {
                    // 距離,ラベルハッシュ
                    List<System.Tuple<float, int>> modelPredictions = new List<System.Tuple<float, int>>();
                    // 距離とラベルを準備
                    model_.predict(line, k, modelPredictions);
                    foreach (var it in modelPredictions)
                    {
                        if (labels.Contains(it.Item2))
                        {
                            precision += 1.0;
                        }
                    }
                    nexamples++;
                    nlabels += labels.Count;
                }
            }

            Console.Write("N");
            Console.Write("\t");
            Console.Write(nexamples);
            Console.Write("\n");
            Console.Write("{0:3}", "P@");
            Console.Write("{0:3}", k);
            Console.Write("{0:3}", "\t");
            Console.Write("{0:3}", precision / (k * nexamples));
            Console.Write("{0:3}", "\n");
            Console.Write("{0:3}", "R@");
            Console.Write("{0:3}", k);
            Console.Write("{0:3}", "\t");
            Console.Write("{0:3}", precision / nlabels);
            Console.Write("{0:3}", "\n");
        }
        #endregion test

        // コマンドライン表示
        //predict()
        // predict()
        //wordVectorsを表示
        // sentenceVectorsを表示
        // ngramVectorsを表示
        // textVectorsを表示
        // printWordVectors
        // printSentenceVectors

        #region train
        public void trainThread(int threadId, string text)
        {
            //ifs.Seek(threadId * ifs.Length / args_.thread, SeekOrigin.Begin);
            //StreamReader sr = new StreamReader(ifs, Encoding.GetEncoding(932));

            Model model = new Model(rndMat, outdicMat, args_, threadId);
            if (args_.modelType == Args.model_name.sup)
            {
                model.setTargetCounts(dict_.getCounts(Dictionary.entry_type.label));
            }
            else
            {
                model.setTargetCounts(dict_.getCounts(Dictionary.entry_type.word));
            }

            long ntokens = dict_.ntokens();
            long localTokenCount = 0;

            var textLines = GetTextLines(text);

            foreach(var textLine in textLines)
            //while (true)
            {
                //if (sr.EndOfStream && ifs.Position >= ifs.Length / args_.thread)
                //    break;

                List<int> line = new List<int>();
                List<int> labels = new List<int>();

                // 行の端は単語が見切れてるので、すべての単語を読みだしたあとに、
                // 行端を確認する必要はない。分かち書きで句読点ごとに行を分割したらバグにならない
                localTokenCount += dict_.getLine(textLine, line, labels, model.rng.Next());

                // tokenCountは行数。この行数でパフォーマンスを調整している
                //if (tokenCount < args_.epoch * ntokens)
                //    break;

                // TODO:progressをArgから解除する変数の作成。わかち書きしたらあてにならん
                float progress = (float)tokenCount / (args_.epoch * ntokens);
                float lr = (float)(args_.lr * (1.0 - progress));

                // CBOWやSkipgramは行数ごとにランダムに起動
                // outDicMatの更新もされる
                if (args_.modelType == Args.model_name.sup)
                {
                    supervised(model, lr, line, labels);
                }
                else if (args_.modelType == Args.model_name.cbow)
                {
                    cbow(model, lr, line);
                }
                else if (args_.modelType == Args.model_name.sg)
                {
                    skipgram(model, lr, line);
                }
                if (localTokenCount > args_.lrUpdateRate)
                {
                    tokenCount += localTokenCount;
                    localTokenCount = 0;
                    if (threadId == 0 && args_.verbose > 1)
                    {
                        printInfo(progress, model.getLoss());
                    }
                }
            }

            model_ = model;

            if (threadId == 0 && args_.verbose > 0)
            {
                printInfo(1.0F, model.getLoss());
            }
            //sr.Close();
            //ifs.Close();
        }

        public void loadVectors(string filename)
        {
            FileStream ofs = new FileStream(filename, FileMode.Create,
                System.IO.FileAccess.Read);

            List<string> words = new List<string>();
            Matrix mat; // temp. matrix for pretrained vectors

            BinaryReader br = new BinaryReader(ofs);
            var n = br.ReadInt64();
            var dim = br.ReadInt64();

            if (dim != args_.dim)
            {
                Console.WriteLine("Dimension of pretrained vectors does not match -dim option");
                Environment.Exit(1);
            }

            mat = new Matrix(n, dim);
            for (uint i = 0; i < n; i++)
            {
                string word = br.ReadString();
                words.Add(word);
                dict_.add(word);

                //var m = br.ReadInt64();

                for (uint j = 0; j < dim; j++)
                {
                    mat.data_[i].data_[j] = (float)br.ReadSingle();
                }
            }
            br.Close();
            ofs.Close();

            dict_.threshold(1, 0);
            //TODO:indicMat = new Matrix(dict_.nwords() + args_.bucket, args_.dim);
            rndMat = new Matrix(dict_.nwords(), args_.dim);
            rndMat.uniform(1 / args_.dim);

            for (int i = 0; i < n; i++)
            {
                int idx = dict_.IndexOf(words[i]);
                if (idx < 0 || idx >= dict_.nwords())
                {
                    continue;
                }
                for (int j = 0; j < dim; j++)
                {
                    rndMat.data_[idx].data_[j] = mat.data_[i].data_[j];
                }
            }
        }

        public void saveVectors()
        {
            FileStream ofs = new FileStream(Path.Combine(System.Windows.Forms.Application.StartupPath, args_.outputName + ".vec"), FileMode.Create,
                System.IO.FileAccess.Write);

            BinaryWriter bw = new BinaryWriter(ofs);
            bw.Write(dict_.nwords());
            bw.Write(args_.dim);

            Vector vec = new Vector(args_.dim);
            for (int i = 0; i < dict_.nwords(); i++)
            {
                string word = dict_.getWord(i);
                getVector(vec, word);

                bw.Write(word);

                // args_.dimがmらしい
                //bw.Write(vec.m_);
                foreach (var vv in vec.data_)
                    bw.Write(vv);
            }
            bw.Close();
            ofs.Close();
        }

        public void train(Args args)
        {
            args_ = args;
            dict_ = new Dictionary(args_);
            if (args_.input == "-")
            {
                // manage expectations
                Console.WriteLine("Cannot use stdin for training!");
                Environment.Exit(1);
            }
            FileStream ifs = new FileStream(args_.input, FileMode.Open, FileAccess.ReadWrite);
            var sr = new StreamReader(ifs, Encoding.GetEncoding(932));
            var text = sr.ReadToEnd();
            dict_.readFromText(text);

            if (args_.pretrainedVectors.Length != 0)
            {
                loadVectors(args_.pretrainedVectors);
            }
            else
            {
                //TODO:indicMat = new Matrix(dict_.nwords() + args_.bucket, args_.dim);
                rndMat = new Matrix(dict_.nwords(), args_.dim);
                rndMat.uniform(1 / args_.dim);
            }

            if (args_.modelType == Args.model_name.sup)
            {
                outdicMat = new Matrix(dict_.nlabels(), args_.dim);
            }
            else
            {
                outdicMat = new Matrix(dict_.nwords(), args_.dim);
            }
            outdicMat.zero();

            //start = clock();
            tokenCount = 0;

            if (args_.thread > 1)
            {
                List <Thread> threads = new List<Thread>();
                for (int i = 0; i < args_.thread; i++)
                {
                    threads.Add(new Thread(() =>
                    {
                        trainThread(i, text);
                    }));
                }

                foreach (var thread in threads)
                {
                    thread.Start();
                }

                foreach (var thread in threads)
                {
                    thread.Join();
                }
            }
            else
            {
                trainThread(0, text);
            }
            ifs.Close();

            //model_ = new Model(input_, output_, args_, Fasttext.Seed());

            saveModel();
            if (args_.modelType != Args.model_name.sup)
            {
                saveVectors();

                if (args_.saveOutput > 0)
                {
                    saveOutput();
                }
            }
        }

        void saveOutput()
        {
            FileStream ofs = new FileStream(Path.Combine(System.Windows.Forms.Application.StartupPath, args_.outputName + ".output"), FileMode.Create,
                System.IO.FileAccess.Write);

            BinaryWriter bw = new BinaryWriter(ofs);
            bw.Write(dict_.nwords());
            bw.Write(args_.dim);

            Vector vec = new Vector(args_.dim);
            for (int i = 0; i < dict_.nwords(); i++)
            {
                string word = dict_.getWord(i);
                vec.zero();
                vec.addRow(outdicMat, i);

                bw.Write(word);

                bw.Write(vec.Count());
                foreach (var vv in vec.data_)
                    bw.Write(vv);
            }
            bw.Close();
            ofs.Close();
        }
        #endregion train

        public static int Seed()
        {
            //var id = Guid.NewGuid().ToString("N").Substring(0, 16);
            //Int32 seed = Convert.ToInt32(id, 8);
            //int seed = id.GetHashCode();

            return 1;
        }

        string[] GetTextLines(string text)
        {
            var lines = text.Split("\r\n".ToCharArray());

            return lines;
        }
    }
}
