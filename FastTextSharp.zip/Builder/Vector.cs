﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastText
{
    public class Vector
    {
        internal float[] data_;

        public Vector(long dim)
        {
            data_ = new float[dim];
        }

        public Vector(float[] data)
        {
            data_ = data;
        }

        #region operator
        public static Vector operator +(Vector word1, Vector word2)
        {
            return word1.Add(word2);
        }

        public static Vector operator +(float[] word1, Vector word2)
        {
            return new Vector(Add(word1, word2.data_));
        }

        public static Vector operator +(Vector word1, float[] word2)
        {
            return new Vector(Add(word1.data_, word2));
        }

        public static Vector operator -(Vector word1, Vector word2)
        {
            return word1.Subtract(word2);
        }

        public static Vector operator -(float[] word1, Vector word2)
        {
            return new Vector(Subtract(word1, word2.data_));
        }

        public static Vector operator -(Vector word1, float[] word2)
        {
            return new Vector(Subtract(word1.data_, word2));
        }

        public static Vector operator *(Vector word1, Vector word2)
        {
            return word1.Multiply(word2);
        }

        public static Vector operator *(float[] word1, Vector word2)
        {
            return new Vector(Multiply(word1, word2.data_));
        }

        public static Vector operator *(Vector word1, float[] word2)
        {
            return new Vector(Multiply(word1.data_, word2));
        }


        public Vector Add(Vector word2)
        {
            return new Vector(Add(data_, word2.data_));
        }

        public Vector Subtract(Vector word2)
        {
            return new Vector(Subtract(data_, word2.data_));
        }

        public Vector Multiply(Vector word2)
        {
            return new Vector(Multiply(data_, word2.data_));
        }


        public static float[] Add(float[] value1, float[] value2)
        {
            if (value1 == null) throw new ArgumentNullException("value1");
            if (value2 == null) throw new ArgumentNullException("value2");
            if (value1.Length != value2.Length) throw new ArgumentException("vector lengths do not match");

            var result = new float[value1.Length];
            for (var i = 0; i < value1.Length; i++)
            {
                result[i] = value1[i] + value2[i];
            }
            return result;
        }

        public static float[] Subtract(float[] value1, float[] value2)
        {
            if (value1 == null) throw new ArgumentNullException("value1");
            if (value2 == null) throw new ArgumentNullException("value2");
            if (value1.Length != value2.Length) throw new ArgumentException("vector lengths do not match");

            var result = new float[value1.Length];
            for (var i = 0; i < value1.Length; i++)
            {
                result[i] = value1[i] - value2[i];
            }
            return result;
        }

        public static float[] Multiply(float[] value1, float[] value2)
        {
            if (value1 == null) throw new ArgumentNullException("value1");
            if (value2 == null) throw new ArgumentNullException("value2");
            if (value1.Length != value2.Length) throw new ArgumentException("vector lengths do not match");

            var result = new float[value1.Length];
            for (var i = 0; i < value1.Length; i++)
            {
                result[i] = value1[i] * value2[i];
            }
            return result;
        }
        #endregion operator

        public long Count() {
            return data_.Count();
        }

        public void zero()
        {
            for (long i = 0; i < data_.Count(); i++)
            {
                data_[i] = 0L;
            }
        }

        public void mul(float a)
        {
            for (long i = 0; i < data_.Count(); i++)
            {
                data_[i] *= a;
            }
        }

        public float norm()
        {
            float sum = 0;
            for (long i = 0; i < data_.Count(); i++)
            {
                sum += data_[i] * data_[i];
            }
            return (float)Math.Sqrt(sum);

            return sum;
        }

        public double Distance(Vector word2)
        {
            return Distance(data_, word2.data_);
        }

        public double Distance(float[] word2)
        {
            return Distance(data_, word2);
        }

        public static double Distance(float[] value1, float[] value2)
        {
            if (value1 == null) throw new ArgumentNullException("value1");
            if (value2 == null) throw new ArgumentNullException("value2");
            if (value1.Length != value2.Length) throw new ArgumentException("vector lengths do not match");

            var dist = 0f;
            for (var i = 0; i < value1.Length; i++)
                dist += value1[i] * value2[i];

            //return dist;

            return Math.Sqrt(dist);
        }

        public void addVector(Vector source)
        {
            Debug.Assert(data_.Count() == source.Count());
            for (long i = 0; i < data_.Count(); i++)
            {
                data_[i] += source.data_[i];
            }
        }
        public void addVector(Vector source, float s)
        {
            Debug.Assert(data_.Count() == source.Count());
            for (long i = 0; i < data_.Count(); i++)
            {
                data_[i] += s * source.data_[i];
            }
        }

        // TODO:間違ってるような・・・
        // Matrixが巨大になるほど、検索が遅くなるはず
        public void addRow(Matrix A, long i)
        {
            Debug.Assert(i >= 0);
            Debug.Assert(i < A.Count());
            Debug.Assert(data_.Count() == A.Dim);
            for (long j = 0; j < A.Dim; j++)
            {
                data_[j] += A.data_[i].data_[j];
            }
        }

        public void addRow(Matrix A, long i, float a)
        {
            Debug.Assert(i >= 0);
            Debug.Assert(i < A.Count());
            Debug.Assert(data_.Count() == A.Dim);
            for (long j = 0; j < A.Dim; j++)
            {
                data_[j] += a * A.data_[i].data_[j];
            }
        }

        public void mul(Matrix A, Vector vec)
        {
            Debug.Assert(A.Count() == data_.Count());
            Debug.Assert(A.Dim == vec.Count());
            for (long i = 0; i < data_.Count(); i++)
            {
                data_[i] = 0;
                for (long j = 0; j < A.Dim; j++)
                {
                    data_[i] += A.data_[i].data_[j] * vec.data_[j];
                }
            }
        }

        public long argmax()
        {
            float max = data_[0];
            long argmax = 0;
            for (long i = 1; i < data_.Count(); i++)
            {
                if (data_[i] > max)
                {
                    max = data_[i];
                    argmax = i;
                }
            }
            return argmax;
        }
    }
}
