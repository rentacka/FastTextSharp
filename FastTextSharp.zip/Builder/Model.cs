﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastText
{
    public class Model
    {
        public class Node
        {
            public int parent;
            public int left;
            public int right;
            public double count;
            public bool binary;
        }

        public const int SIGMOID_TABLE_SIZE = 512;
        public const int MAX_SIGMOID = 8;
        public const int LOG_TABLE_SIZE = 512;
        public const int NEGATIVE_TABLE_SIZE = 10000000;

        /// <summary>
        /// ランダムな-0～1.0のテーブル
        /// </summary>
        Matrix rndMat;
        /// <summary>
        /// 計算後のマトリックス
        /// </summary>
        internal Matrix OutputMat;

        int negativeMax;
        Args.loss_name lossType;
        Args.model_name modelType;

        /// <summary>
        /// シグモイド関数とソフトマックス関数でつかう隠れベクトル
        /// </summary>
        Vector hidden_ = null;
        Vector output_ = null;
        Vector grad_ = null;
        long dim_ { get { return rndMat.Dim; } }

        /// <summary>
        /// シグモイド関数とソフトマックス関数のscoreLoss
        /// </summary>
        float loss_ = 0;
        long nexamples_;
        float[] t_sigmoid;
        float[] t_log;
        // used for negative sampling:
        List<int> negatives = new List<int>();
        int negpos;
        // used for hierarchical softmax:
        List<List<int>> paths = new List<List<int>>();
        List<List<bool>> codes = new List<List<bool>>();
        Node[] tree = null;
        internal Random rng = null;

        void Shuffule(List<int> ary)
        {
            //シャッフルする
            int[] ary2 = ary.OrderBy(i => Guid.NewGuid()).ToArray();
            ary.Clear();
            ary.AddRange(ary2);
        }

        internal Model(Matrix wi,Matrix wo, Args args, int seed)
        {
            Init(wi, wo, args, seed);
        }

        internal Model(Matrix wi, Matrix wo, int negativeMax, Args.loss_name lossType, Args.model_name modelType)
        {
            Args args = new Args();
            args.lossType = lossType;
            args.modelType = modelType;
            args.neg = negativeMax;
            Init(wi, wo, args, Fasttext.Seed());
        }

        void Init(Matrix wi, Matrix wo, Args args, int seed)
        {
            this.hidden_ = new Vector(args.dim);
            this.output_ = new Vector(wo.Count());
            this.grad_ = new Vector(args.dim);
            this.rng = new Random(seed);
            rndMat = wi;
            OutputMat = wo;


            negativeMax = args.neg;
            modelType = args.modelType;
            lossType = args.lossType;

            negpos = 0;
            loss_ = 0.0F;
            nexamples_ = 1;
            initSigmoid();
            initLog();
        }

        public float binaryLogistic(int target, bool label, float lr)
        {
            // 1/e^-x シグモイド関数
            float score = sigmoid(OutputMat.dotRow(hidden_, target));
            float alpha = lr * ((Convert.ToInt32(label)) - score);
            grad_.addRow(OutputMat, target, alpha);
            OutputMat.addRow(hidden_, target, alpha);
            if (label)
            {
                return (float)-Math.Log(score);
            }
            else
            {
                return (float)-Math.Log(1.0 - score);
            }
        }
        public float negativeSampling(int target, float lr)
        {
            float loss = 0.0F;
            grad_.zero();
            for (int n = 0; n <= negativeMax; n++)
            {
                if (n == 0)
                {
                    loss += binaryLogistic(target, true, lr);
                }
                else
                {
                    loss += binaryLogistic(getNegative(target), false, lr);
                }
            }
            return loss;
        }
        public float hierarchicalSoftmax(int target, float lr)
        {
            float loss = 0.0F;
            grad_.zero();
            List<bool> binaryCode = codes[target];
            List<int> pathToRoot = paths[target];
            for (int i = 0; i < pathToRoot.Count; i++)
            {
                loss += binaryLogistic(pathToRoot[i], binaryCode[i], lr);
            }
            return loss;
        }
        internal void computeOutputSoftmax(Vector hidden, Vector output)
        {
            output.mul(OutputMat, hidden);
            float max = output.data_[0];
            float z = 0.0F;
            for (int i = 0; i < OutputMat.Count(); i++)
            {
                max = Math.Max(output.data_[i], max);
            }
            for (int i = 0; i < OutputMat.Count(); i++)
            {
                output.data_[i] = (float)Math.Exp(output.data_[i] - max);
                z += output.data_[i];
            }
            for (int i = 0; i < OutputMat.Count(); i++)
            {
                output.data_[i] /= z;
            }
        }
        public void computeOutputSoftmax()
        {
            computeOutputSoftmax(hidden_, output_);
        }

        public float softmax(int target, float lr)
        {
            grad_.zero();
            computeOutputSoftmax();
            for (int i = 0; i < OutputMat.Count(); i++)
            {
                var label = (i == target) ? 1.0 : 0.0;
                var alpha = (float)(lr * (label - output_.data_[i]));
                grad_.addRow(OutputMat, i, alpha);
                OutputMat.addRow(hidden_, i, alpha);
            }
            return (float)-Math.Log(output_.data_[target]);
        }
        internal void computeHidden(List<int> input, Vector hidden)
        {
            Debug.Assert(hidden.Count() == dim_);
            hidden.zero();
            foreach (var it in input)
            {
                // 入力辞書を隠れベクトルに追加
                hidden.addRow(rndMat, it);
            }
            hidden.mul((float)(1.0 / input.Count));
        }
        public IComparer<System.Tuple<float, int>> comparePairs(System.Tuple<float, int> l, System.Tuple<float, int> r)
        {
           // = l.Item1.CompareTo(r.Item1);

            return null;
        }
        internal void predict(List<int> input, int k, List<System.Tuple<float, int>> heap, Vector hidden, Vector output)
        {
            Debug.Assert(k > 0);
            heap.Capacity = k + 1;
            computeHidden(input, hidden);
            if (lossType == Args.loss_name.hs)
            {
                // 2 * osz_ - 2が現在のノード位置
                dfs(k, (int)(2 * OutputMat.Count() - 2), 0.0F, heap, hidden);
            }
            else
            {
                findKBest(k, heap, hidden, output);
            }
            //std::sort_heap(heap.GetEnumerator(), heap.end(), comparePairs);
            //TODO:heap.Sort(0,heap.Count, comparePairs); たぶんいけてる？
            heap.Sort();
        }
        public void predict(List<int> input, int k, List<System.Tuple<float, int>> heap)
        {
            predict(input, k, heap, hidden_, output_);
        }
        internal void findKBest(int k, List<System.Tuple<float, int>> heap, Vector hidden, Vector output)
        {
            computeOutputSoftmax(hidden, output);
            for (int i = 0; i < OutputMat.Count(); i++)
            {
                if (heap.Count == k && Math.Log(output.data_[i]) < heap[0].Item1)
                {
                    continue;
                }
                heap.Add(System.Tuple.Create((float)Math.Log(output.data_[i]), i));
                //std::push_heap(heap.GetEnumerator(), heap.end(), comparePairs);
                heap.Sort();

                if (heap.Count > k)
                {
                    //std::pop_heap(heap.GetEnumerator(), heap.end(), comparePairs);
                    //heap.RemoveAt(heap.Count - 1);
                    heap.RemoveAt(0);
                }
            }
        }

        /// <summary>
        /// シグモイド関数で最適化
        /// </summary>
        /// <param name="k"></param>
        /// <param name="node"></param>
        /// <param name="score"></param>
        /// <param name="heap"></param>
        /// <param name="hidden"></param>
        internal void dfs(int k, int node, float score, List<System.Tuple<float, int>> heap, Vector hidden)
        {
            if (heap.Count == k && score < heap[0].Item1)
            {
                return;
            }

            if (tree[node].left == -1 && tree[node].right == -1)
            {
                //std::push_heap(heap.GetEnumerator(), heap.end(), comparePairs);
                heap.Add(System.Tuple.Create(score, node));

                if (heap.Count > k)
                {
                    //std::pop_heap(heap.GetEnumerator(), heap.end(), comparePairs);
                    //heap.RemoveAt(heap.Count - 1);
                    heap.RemoveAt(0);
                }
                return;
            }

            float f = sigmoid(OutputMat.dotRow(hidden, node - OutputMat.Count()));
            dfs(k, tree[node].left, (float)(score + Math.Log(1.0 - f)), heap, hidden);
            dfs(k, tree[node].right, (float)(score + Math.Log(f)), heap, hidden);
        }

        /// <summary>
        /// 隠れ層と出力層のコーパスを計算
        /// </summary>
        /// <param name="input">入力文字列</param>
        /// <param name="target">文字列</param>
        /// <param name="lr"></param>
        public void updateCorpas(List<int> input, int target, float lr)
        {
            Debug.Assert(target >= 0);
            Debug.Assert(target < OutputMat.Count());
            if (input.Count == 0)
            {
                return;
            }
            computeHidden(input, hidden_);
            if (lossType == Args.loss_name.ns)
            {
                loss_ += negativeSampling(target, lr);
            }
            else if (lossType == Args.loss_name.hs)
            {
                loss_ += hierarchicalSoftmax(target, lr);
            }
            else
            {
                loss_ += softmax(target, lr);
            }
            nexamples_ += 1;

            if (modelType == Args.model_name.sup)
            {
                grad_.mul(1.0F / input.Count);
            }
            foreach (var it in input)
            {
                //TODO:訂正(inputのIdxはあってるのだろうか) サブワードのMatrixに加算
                rndMat.addRow(grad_, it, 1.0F);
            }
        }
        public void setTargetCounts(List<long> counts)
        {
            Debug.Assert(counts.Count == OutputMat.Count());
            if (lossType == Args.loss_name.ns)
            {
                initTableNegatives(counts);
            }
            if (lossType == Args.loss_name.hs)
            {
                buildTree(counts);
            }
        }
        public void initTableNegatives(List<long> counts)
        {
            var z = 0.0;
            for (int i = 0; i < counts.Count; i++)
            {
                z += Math.Pow(counts[i], 0.5);
            }
            for (int i = 0; i < counts.Count; i++)
            {
                var c = Math.Pow(counts[i], 0.5);
                for (uint j = 0; j < c * NEGATIVE_TABLE_SIZE / z; j++)
                {
                    negatives.Add(i);
                }
            }
            Shuffule(negatives);

        }
        public int getNegative(int target)
        {
            int negative;
            do
            {
                negative = negatives[negpos];
                negpos = (negpos + 1) % negatives.Count;
            } while (target == negative);
            return negative;
        }
        public void buildTree(List<long> counts)
        {
            Array.Resize(ref tree, (int)(2 * OutputMat.Count() - 1));

            for (int i = 0; i < 2 * OutputMat.Count() - 1; i++)
            {
                tree[i].parent = -1;
                tree[i].left = -1;
                tree[i].right = -1;
                tree[i].count = 1e15;
                tree[i].binary = false;
            }
            for (int i = 0; i < OutputMat.Count(); i++)
            {
                tree[i].count = counts[i];
            }
            int leaf = (int)OutputMat.Count() - 1;
            int node = (int)OutputMat.Count();
            for (int i = (int)OutputMat.Count(); i < 2 * OutputMat.Count() - 1; i++)
            {
                int[] mini = new int[2];
                for (int j = 0; j < 2; j++)
                {
                    if (leaf >= 0 && tree[leaf].count < tree[node].count)
                    {
                        mini[j] = leaf--;
                    }
                    else
                    {
                        mini[j] = node++;
                    }
                }
                tree[i].left = mini[0];
                tree[i].right = mini[1];
                tree[i].count = tree[mini[0]].count + tree[mini[1]].count;
                tree[mini[0]].parent = i;
                tree[mini[1]].parent = i;
                tree[mini[1]].binary = true;
            }
            for (int i = 0; i < OutputMat.Count(); i++)
            {
                List<int> path = new List<int>();
                List<bool> code = new List<bool>();
                int j = i;
                while (tree[j].parent != -1)
                {
                    path.Add((int)(tree[j].parent - OutputMat.Count()));
                    code.Add(tree[j].binary);
                    j = tree[j].parent;
                }
                paths.Add(path);
                codes.Add(code);
            }
        }

        public float getLoss()
        {
            return loss_ / nexamples_;
        }
        public void initSigmoid()
        {
            t_sigmoid = Arrays.InitializeWithDefaultInstances<float>(SIGMOID_TABLE_SIZE + 1);
            for (int i = 0; i < SIGMOID_TABLE_SIZE + 1; i++)
            {
                float x = (i * 2 * MAX_SIGMOID) / SIGMOID_TABLE_SIZE - MAX_SIGMOID;
                t_sigmoid[i] = (float)(1.0 / (1.0 + Math.Exp(-x)));
            }
        }
        public void initLog()
        {
            t_log = Arrays.InitializeWithDefaultInstances<float>(LOG_TABLE_SIZE + 1);
            for (int i = 0; i < LOG_TABLE_SIZE + 1; i++)
            {
                var x = ((i) + 1e-5) / LOG_TABLE_SIZE;
                t_log[i] = (float)Math.Log(x);
            }
        }
        public float log(float x)
        {
            if (x > 1.0)
            {
                return 0.0F;
            }
            int i = (int)(x * LOG_TABLE_SIZE);
            return t_log[i];
        }

        /// <summary>
        /// 1/e^-x シグモイド関数
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public float sigmoid(float x)
        {
            if (x < -MAX_SIGMOID)
            {
                return 0.0F;
            }
            else if (x > MAX_SIGMOID)
            {
                return 1.0F;
            }
            else
            {
                int i = (int)(x + MAX_SIGMOID) * SIGMOID_TABLE_SIZE / MAX_SIGMOID / 2;

                return t_sigmoid[i];
            }
        }

    }
}
