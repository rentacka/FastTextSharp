﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastText
{
    /// <summary>
    /// TODO:NN計算 ∑n/2^n 大いにまちがっている ModelPreviewでやる方が早い
    /// </summary>
    public class NN
    {
        internal Fasttext fasttext;

        Vector queryVec = null;
        /// <summary>
        /// NN計算したWordVector
        /// </summary>
        internal Matrix wordVectors = null;

        internal NN(Fasttext fastText)
        {
            fasttext = fastText;

            queryVec = new Vector(fasttext.args_.dim);
            wordVectors = new Matrix(fasttext.dict_.nwords(), fasttext.args_.dim);

            precomputeWordVectors(wordVectors);
        }

        internal List<System.Tuple<float, string>> findNN(Matrix wordVectors, Vector queryVec, int k, SortedSet<string> banSet)
        {
            float queryNorm = queryVec.norm();
            if (Math.Abs(queryNorm) < 1e-8)
            {
                queryNorm = 1;
            }
            Queue<System.Tuple<float, string>> heap = new Queue<System.Tuple<float, string>>();
            Vector vec = new Vector(fasttext.args_.dim);
            for (int i = 0; i < fasttext.dict_.nwords(); i++)
            {
                string word = fasttext.dict_.getWord(i);
                int idx = fasttext.dict_.IndexOf(word);


                float dp = wordVectors.dotRow(queryVec, i);
                //TODO:ここの計算が同じ値になってておかしい
                heap.Enqueue(System.Tuple.Create((dp / queryNorm), word));
            }
            int j = 0;

            var result = new List<System.Tuple<float, string>>();
            while (j < k && heap.Count > 0)
            {
                if (banSet.Contains(heap.First().Item2))
                {
                    result.Add(heap.First());

                    j++;
                }
                heap.Dequeue();
            }

            return result;
        }

        internal void precomputeWordVectors(Matrix wordVectors)
        {
            Vector vec = new Vector(fasttext.args_.dim);
            wordVectors.zero();

            // Pre-computing word vectors
            for (int i = 0; i < fasttext.dict_.nwords(); i++)
            {
                string word = fasttext.dict_.getWord(i);
                fasttext.getVector(vec, word);

                // ∑n/2^n NN計算
                float norm = vec.norm();
                wordVectors.addRow(vec, i, 1.0F / norm);
            }
        }

        public List<System.Tuple<float, string>> NearestWords_NN(string queryWord, int count)
        {
            SortedSet<string> banSet = new SortedSet<string>();

            banSet.Clear();
            banSet.Add(queryWord);
            queryVec.zero();
            fasttext.getVector(queryVec, queryWord);
            var wordVecs = findNN(wordVectors, queryVec, count, banSet);

            return wordVecs;
        }
    }
}
