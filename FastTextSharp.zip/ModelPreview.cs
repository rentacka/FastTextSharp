﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace FastText
{
    public class ModelPreview
    {
        /// <summary>
        /// 語数
        /// </summary>
        public int Words { get { return Vectors.Count(); } }
        /// <summary>
        /// ベクトルのサイズ
        /// </summary>
        public int Size
        {
            get
            {
                return model.First().data_.Length;
            }
        }

        List<RowVector> model = new List<RowVector>();

        public IEnumerable<RowVector> Vectors => this.model;

        public ModelPreview(Fasttext fastText)
        {
            model.Clear();

            //var queryVec = new Vector(fastText.model_.OutputMat.Dim);
            var wordVectors = fastText.model_.OutputMat;

            foreach (var vocab in fastText.dict_.vocabWords_)
            {
                var row = new RowVector(vocab.word, wordVectors.data_[fastText.dict_.IndexOf(vocab.word)]);
                model.Add(row);
            }
        }

        public ModelPreview(Matrix wordVectors, string[] vocabWords_)
        {
            model.Clear();

            int i = 0;
            foreach (var vocab in vocabWords_)
            {
                var row = new RowVector(vocabWords_[i], wordVectors.data_[i]);
                model.Add(row);
            }
        }

        public ModelPreview(List<RowVector> vectors)
        {
            this.model = vectors;
        }

        /// <summary>
        /// 制限モデル
        /// </summary>
        /// <param name="words">語数</param>
        /// <param name="size">200〜1000次元のベクトルがおすすめ</param>
        /// <param name="vectors"></param>
        public ModelPreview(int words, int size, List<RowVector> vectors)
        {
            List<RowVector> vectors2 = new List<RowVector>();
            int i = 0;
            // 語数制限
            foreach (var vec in vectors)
            {
                if (i < words)
                {
                    // 距離制限
                    int j = 0;
                    List<float> vec2List = new List<float>();
                    foreach (var vec2 in vec.data_)
                    {
                        if (j < size)
                        {
                            vec2List.Add(vec2);

                            j++;
                        }
                    }

                    // 追加
                    var target = new RowVector(vec.Word, vec2List.ToArray());
                    vectors2.Add(target);

                    i++;
                }
            }

            this.model = vectors;
        }

        public double Distance(string word1, string word2)
        {
            var vector1 = GetByWord(word1);
            var vector2 = GetByWord(word2);
            if (vector1 == null) throw new ArgumentException(string.Format("cannot find word1 '{0}'", word1));
            if (vector2 == null) throw new ArgumentException(string.Format("cannot find word2 '{0}'", word2));

            return vector1.Distance(vector2);
        }


        public IEnumerable<WordDistance> NearestWords(float[] vec, int count)
        {
            if (vec == null) return new List<WordDistance>();
            var bestd = new float[count];
            var bestw = new string[count];

            for (var n = 0; n < count; n++) bestd[n] = -1;

            foreach (var key in model)
            {
                var dist = 0f;
                for (var i = 0; i < Size; i++) dist += vec[i] * key.data_[i];
                for (var c = 0; c < count; c++)
                    if (dist > bestd[c])
                    {
                        for (var i = count - 1; i > c; i--)
                        {
                            bestd[i] = bestd[i - 1];
                            bestw[i] = bestw[i - 1];
                        }
                        bestd[c] = dist;
                        bestw[c] = key.Word;
                        break;
                    }
            }
            var result = new List<WordDistance>();
            for (var i = 0; i < count; i++)
                result.Add(new WordDistance(bestw[i], bestd[i]));

            return result;
        }

        public IEnumerable<WordDistance> NearestWords(string word, int count)
        {
            var vec = GetByWord(word);

            if (vec != null)
                return NearestWords(vec.data_, count);
            else
                return new List<WordDistance>();
        }

        public RowVector GetByWord(string word)
        {
            foreach (var vec in Vectors)
                if (vec.Word == word)
                    return vec;

            return null;
        }

        /// <summary>
        /// Corps File
        /// </summary>
        /// <param name="model_file">Word And Vectors</param>
        public static ModelPreview LoadFastText(string model_file)
        {
            Fasttext fastText = new Fasttext();
            fastText.loadModel(model_file);

            var modeler = new ModelPreview(fastText);

            return modeler;
        }

        public static ModelPreview Load(string modelpreview_file)
        {
            List<RowVector> model = new List<RowVector>();
            var file = modelpreview_file;
            using (var br = new BinaryReader(File.Open(file, FileMode.Open)))
            {
                var wordCount = br.ReadInt32();
                for (int i=0;i<wordCount;i++)
                {
                    // Word
                    var Word = br.ReadString();

                    // ベクトル
                    var vecCount = br.ReadInt64();
                    var data = new float[vecCount -1];
                    for (long ii = 0; ii < vecCount; ii++)
                        data[ii] = br.ReadSingle();

                    var vec = new RowVector(Word, data);

                    model.Add(vec);
                }
            }

            return new ModelPreview(model);
        }

        /// <summary>
        /// modelpreview_file
        /// </summary>
        /// <param name="modelpreview_file">Word And Vectors</param>
        public void Save(string modelpreview_file)
        {
            var file = modelpreview_file;
            using (var br = new BinaryWriter(File.Open(file, FileMode.Open)))
            {
                br.Write(model.Count);
                foreach (var vec in model)
                {
                    // Word
                    br.Write(vec.Word);

                    // ベクトル
                    br.Write(vec.Count());
                    foreach (var data in vec.data_)
                        br.Write(data);
                }
            }
        }

        private static void Normalise(float[] vec,int Dimensions)
        {
            var len = 0f;
            for (var i = 0; i < Dimensions; i++) len += vec[i] * vec[i];
            len = (float)Math.Sqrt(len);
            for (var i = 0; i < Dimensions; i++) vec[i] /= len;
        }

        public struct WordDistance
        {
            public WordDistance(string word, double distance)
            {
                this.Key = word;
                this.Value = distance;
            }

            public string Key { get; private set; }
            public double Value { get; private set; }

            public override string ToString()
            {
                return string.Format("{0} ({1})", this.Key, this.Value);
            }
        }
    }
}
