﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastText
{
    public class Vector
    {

        internal long m_;
        internal float[] data_;

        public Vector(long m)
        {
            m_ = m;
            data_ = new float[m];
        }

        public long size() {
            return m_;
        }


        public void zero()
        {
            for (long i = 0; i < m_; i++)
            {
                data_[i] = 0L;
            }
        }

        public void mul(float a)
        {
            for (long i = 0; i < m_; i++)
            {
                data_[i] *= a;
            }
        }

        public float norm()
        {
            float sum = 0;
            for (long i = 0; i < m_; i++)
            {
                sum += data_[i] * data_[i];
            }
            return (float)Math.Sqrt(sum);
        }

        public void addVector(Vector source)
        {
            Debug.Assert(m_ == source.m_);
            for (long i = 0; i < m_; i++)
            {
                data_[i] += source.data_[i];
            }
        }
        public void addVector(Vector source, float s)
        {
            Debug.Assert(m_ == source.m_);
            for (long i = 0; i < m_; i++)
            {
                data_[i] += s * source.data_[i];
            }
        }

        // TODO:間違ってるような・・・
        // Matrixが巨大になるほど、検索が遅くなるはず
        public void addRow(Matrix A, long i)
        {
            Debug.Assert(i >= 0);
            Debug.Assert(i < A.m_);
            Debug.Assert(m_ == A.n_);
            for (long j = 0; j < A.n_; j++)
            {
                data_[j] += A.data_[i * A.n_ + j];
            }
        }

        public void addRow(Matrix A, long i, float a)
        {
            Debug.Assert(i >= 0);
            Debug.Assert(i < A.m_);
            Debug.Assert(m_ == A.n_);
            for (long j = 0; j < A.n_; j++)
            {
                data_[j] += a * A.data_[i * A.n_ + j];
            }
        }

        public void mul(Matrix A, Vector vec)
        {
            Debug.Assert(A.m_ == m_);
            Debug.Assert(A.n_ == vec.m_);
            for (long i = 0; i < m_; i++)
            {
                data_[i] = 0;
                for (long j = 0; j < A.n_; j++)
                {
                    data_[i] += A.data_[i * A.n_ + j] * vec.data_[j];
                }
            }
        }

        public long argmax()
        {
            float max = data_[0];
            long argmax = 0;
            for (long i = 1; i < m_; i++)
            {
                if (data_[i] > max)
                {
                    max = data_[i];
                    argmax = i;
                }
            }
            return argmax;
        }
    }
}
