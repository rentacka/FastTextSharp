﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastText
{
    public class Matrix
    {
        internal float[] data_;
        internal long m_;
        internal long n_;

        public Matrix() {
            m_ = 0;
            n_ = 0;
            data_ = null;
        }


        public Matrix(long m, long n) {
            m_ = m;
            n_ = n;
            data_ = new float[m * n];
        }


        public Matrix(Matrix other) {
            m_ = other.m_;
            n_ = other.n_;
            data_ = new float[m_ * n_];
            for (long i = 0; i < (m_ * n_); i++) {
                data_[i] = other.data_[i];
            }
        }

        #region operator
        public static Matrix operator +(Matrix word1, Matrix word2)
        {

            return word1.Add(word2);
        }

        public Matrix Add(Matrix word2)
        {
            var sum = Matrix.Add(data_, word2.data_);

            Matrix temp = new Matrix();
            temp.data_ = sum;
            temp.m_ = m_;
            temp.n_ = n_;

            return temp;
        }

        public static float[] Add(float[] value1, float[] value2)
        {
            if (value1 == null) throw new ArgumentNullException("value1");
            if (value2 == null) throw new ArgumentNullException("value2");
            if (value1.Length != value2.Length) throw new ArgumentException("vector lengths do not match");

            var result = new float[value1.Length];
            for (var i = 0; i < value1.Length; i++)
            {
                result[i] = value1[i] + value2[i];
            }
            return result;
        }
        #endregion operator


        public void zero()
        {
            for (long i = 0; i < (m_ * n_); i++)
            {
                data_[i] = 0L;
            }
        }

        public void uniform(int a)
        {
            var round = new Random(Fasttext.Seed());

            for (long i = 0; i < (m_ * n_); i++)
            {
                data_[i] = round.Next(-a, a);
            }
        }

        public void addRow(Vector vec, long i, float a)
        {
            Debug.Assert(i >= 0);
            Debug.Assert(i < m_);
            Debug.Assert(vec.m_ == n_);
            for (long j = 0; j < n_; j++)
            {
                data_[i * n_ + j] += a * vec.data_[j];
            }
        }

        public long dotRow(Vector vec, long i)
        {
            Debug.Assert(i >= 0);
            Debug.Assert(i < m_);
            Debug.Assert(vec.m_ == n_);
            float d = 0f;
            for (long j = 0; j < n_; j++)
            {
                d += data_[i * n_ + j] * vec.data_[j];
            }
            return (long)d;
        }

        public void save(BinaryWriter stream)
        {
            stream.Write(m_);
            stream.Write(n_);

            foreach (var bit in data_)
                stream.Write(bit);
        }

        public void load(BinaryReader stream)
        {
            m_ = stream.ReadInt64();
            n_ = stream.ReadInt64();

            data_ = new float[m_ * n_];
            for (long i = 0; i < m_; i++)
            {
                for (long j = 0; j < m_; j++)
                {
                    var bit = stream.ReadInt64();
                    data_[i * j] = bit;
                }
            }
        }

    }
}
