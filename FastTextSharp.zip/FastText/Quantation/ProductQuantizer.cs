﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastText
{
    internal static class Arrays
    {
        internal static T[] InitializeWithDefaultInstances<T>(int length) where T : new()
        {
            T[] array = new T[length];
            for (int i = 0; i < length; i++)
            {
                array[i] = new T();
            }
            return array;
        }

        internal static void DeleteArray<T>(T[] array) where T : System.IDisposable
        {
            foreach (T element in array)
            {
                if (element != null)
                    element.Dispose();
            }
        }
    }

    class ProductQuantizer
    {
        private float distL2(float[] x, float[] y, int d)
        {
            float dist = 0;
            for (var i = 0; i < d; i++)
            {
                var tmp = x[i] - y[i];
                dist += tmp * tmp;
            }
            return dist;
        }

        const int nbits_ = 8;
        int ksub_ = 1 << nbits_;
        const int max_points_per_cluster_ = 256;
        int max_points_ = 0;
        const int seed_ = 1234;
        const int niter_ = 25;
        const double eps_ = 1e-7;

        int dim_;
        int nsubq_;
        int dsub_;
        int lastdsub_;

        float[] centroids_ = null;

        Random rng;

        public ProductQuantizer(int dim, int dsub)
        {
            seed_ = Fasttext.Seed();
            max_points_ = max_points_per_cluster_ * ksub_;

            this.dim_ = dim;
            this.nsubq_ = dim / dsub;
            this.dsub_ = dsub;
            this.centroids_ = new List<float>(dim * ksub_);
            this.rng = new Random(seed_);
            lastdsub_ = dim_ % dsub;
            if (lastdsub_ == 0)
            {
                lastdsub_ = dsub_;
            }
            else
            {
                nsubq_++;
            }
        }
        public float get_centroids(int m, byte i)
        {
            if (m == nsubq_ - 1)
            {
                return centroids_[m * ksub_ * dsub_ + i * lastdsub_];
            }
            return centroids_[(m * ksub_ + i) * dsub_];
        }

        public float assign_centroid(float[] x, float[] c0, byte[] code, int d)
        {
            float[] c = c0;
            float dis = distL2(x, c, d);
            code[0] = 0;
            for (var j = 1; j < ksub_; j++)
            {
                // c += d;
                c[j - 1] = c[j-1] + d;
                float disij = distL2(x, c, d);
                if (disij < dis)
                {
                    code[0] = (byte)j;
                    dis = disij;
                }
            }
            return dis;
        }

        public void Estep(float x, float centroids, ref byte codes, int d, int n)
        {
            for (var i = 0; i < n; i++)
            {
                assign_centroid(x + i * d, centroids, codes + i, d);
            }
        }
        public void MStep(float x0, float centroids, byte[] codes, int d, int n)
        {
            List<int> nelts = new List<int>(ksub_, 0);
            //C++ TO C# CONVERTER TODO TASK: The memory management function 'memset' has no equivalent in C#:
            memset(centroids, 0, sizeof(float) * d * ksub_);
            float[] x = x0;
            for (var i = 0; i < n; i++)
            {
                var k = codes[i];
                float[] c = centroids + k * d;
                for (var j = 0; j < d; j++)
                {
                    c[j] += x[j];
                }
                nelts[k]++;
                x += d;
            }

            float[] c = centroids;
            for (var k = 0; k < ksub_; k++)
            {
                float z = (float)nelts[k];
                if (z != 0)
                {
                    for (var j = 0; j < d; j++)
                    {
                        c[j] /= z;
                    }
                }
                c += d;
            }

            std::uniform_float_distribution<> runiform = new std::uniform_float_distribution<>(0, 1);
            for (var k = 0; k < ksub_; k++)
            {
                if (nelts[k] == 0)
                {
                    int m = 0;
                    while (runiform(rng) * (n - ksub_) >= nelts[m] - 1)
                    {
                        m = (m + 1) % ksub_;
                    }
                    //C++ TO C# CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in C#:
                    memcpy(centroids + k * d, centroids + m * d, sizeof(float) * d);
                    for (var j = 0; j < d; j++)
                    {
                        int sign = (j % 2) * 2 - 1;
                        centroids[k * d + j] += sign * eps_;
                        centroids[m * d + j] -= sign * eps_;
                    }
                    nelts[k] = nelts[m] / 2;
                    nelts[m] -= nelts[k];
                }
            }
        }

        void kmeans(float x, float c, int n, int d)
        {
            List<int> perm = new List<int>(n, 0);
            std::iota(perm.GetEnumerator(), perm.end(), 0);
            std::shuffle(perm.GetEnumerator(), perm.end(), rng);
            for (var i = 0; i < ksub_; i++)
            {
                //C++ TO C# CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in C#:
                memcpy(c[i * d], x + perm[i] * d, d * sizeof(float));
            }
            byte[] codes = new byte[n];
            for (var i = 0; i < niter_; i++)
            {

                Estep(x, c, codes, d, n);

                MStep(x, c, codes, d, n);
            }
            codes = null;
        }

        public void train(int n, float[] x)
        {
            if (n < ksub_)
            {
                std::cerr << "Matrix too small for quantization, must have > 256 rows" << std::endl;
                Environment.Exit(1);
            }
            List<int> perm = new List<int>(n);
            std::iota(perm.GetEnumerator(), perm.end(), 0);
            var d = dsub_;
            var np = Math.Min(n, max_points_);
            float[] xslice = Arrays.InitializeWithDefaultInstances<float>(np * dsub_);
            for (var m = 0; m < nsubq_; m++)
            {
                if (m == nsubq_ - 1)
                {
                    d = lastdsub_;
                }
                if (np != n)
                {
                    std::shuffle(perm.GetEnumerator(), perm.end(), rng);
                }
                for (var j = 0; j < np; j++)
                {
                    //C++ TO C# CONVERTER TODO TASK: The memory management function 'memcpy' has no equivalent in C#:
                    memcpy(xslice + j * d, x + perm[j] * dim_ + m * dsub_, d * sizeof(float));
                }
                kmeans(xslice, get_centroids(m, 0), np, d);
            }
            xslice = null;
        }
        public float mulcode(Vector x, byte codes, int t, float alpha)
        {
            float res = 0.0;
            var d = dsub_;
            byte[] code = codes + nsubq_ * t;
            for (var m = 0; m < nsubq_; m++)
            {
                float c = get_centroids(m, code[m]);
                if (m == nsubq_ - 1)
                {
                    d = lastdsub_;
                }
                for (var n = 0; n < d; n++)
                {
                    res += x[m * dsub_ + n] * c[n];
                }
            }
            return res * alpha;
        }

        public void addcode(Vector x, byte codes, int t, float alpha)
        {
            var d = dsub_;
            byte[] code = codes + nsubq_ * t;
            for (var m = 0; m < nsubq_; m++)
            {
                float c = get_centroids(m, code[m]);
                if (m == nsubq_ - 1)
                {
                    d = lastdsub_;
                }
                for (var n = 0; n < d; n++)
                {
                    x[m * dsub_ + n] += alpha * c[n];
                }
            }
        }
        public void compute_code(float x, ref byte code)
        {
            var d = dsub_;
            for (var m = 0; m < nsubq_; m++)
            {
                if (m == nsubq_ - 1)
                {
                    d = lastdsub_;
                }
                assign_centroid(x + m * dsub_, get_centroids(m, 0), code + m, d);
            }
        }
        public void compute_codes(float x, ref byte codes, int n)
        {
            for (var i = 0; i < n; i++)
            {
                compute_code(x + i * dim_, codes + i * nsubq_);
            }
        }
        public void save(std::ostream @out)
        {
            @out.write((string)&dim_, sizeof(dim_));
            @out.write((string)&nsubq_, sizeof(nsubq_));
            @out.write((string)&dsub_, sizeof(dsub_));
            @out.write((string)&lastdsub_, sizeof(lastdsub_));
            @out.write((string)centroids_.data(), centroids_.size() * sizeof(float));
        }
        public void load(std::istream in)
        {
	  in.read((string)&dim_, sizeof(dim_));
	  in.read((string)&nsubq_, sizeof(nsubq_));
	  in.read((string)&dsub_, sizeof(dsub_));
	  in.read((string)&lastdsub_, sizeof(lastdsub_));

            Array.Resize(ref centroids_, dim_ * ksub_);
            for (var i = 0; i < centroids_.size(); i++)
            {
		in.read((string)&centroids_[i], sizeof(float));
            }
        }

    }
}
