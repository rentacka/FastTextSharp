﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastText
{
    /// <summary>
    /// N-gram
    /// </summary>
    public static class Ngram
    {
        public enum GramMode
        {
            Unigram = 1,
            Bigram = 2,
            Trigram = 3,
            Sigram = 4,
            Figram =5
        }

        public static IEnumerable<string> GetNGrams(string word)
        {
            return GetNGrams(GramMode.Trigram, word);
        }

        public static IEnumerable<string> GetNGrams(GramMode mode, string word)
        {
            var n = (int)mode;
            for (var i = 0; i <= word.Length - n; i++)
            {
                yield return word.Substring(i, n);
            }
        }

        internal static IEnumerable<string> GetNGrams(int n, string word)
        {
            for (var i = 0; i <= word.Length - n; i++)
            {
                yield return word.Substring(i, n);
            }
        }

        public static decimal CompareNGram(GramMode mode,string s, string t)
        {
            return Compare((int)mode, s, t);
        }

        private static decimal Compare(int n, string s, string t)
        {
            if (s == null) throw new ArgumentNullException("s");
            if (t == null) throw new ArgumentNullException("t");

            var noise = new List<string>();
            for (int i = 0; i < s.Length - (n - 1); i++)
            {
                var ngitem = s.Substring(i, n);
                if (!noise.Contains(ngitem)) { noise.Add(ngitem); }
            }
            if (noise.Count == 0) return 0;

            int coincidence = 0;
            for (int i = 0; i < t.Length - (n - 1); i++)
            {
                var ngitem = t.Substring(i, n);
                if (noise.Contains(ngitem)) { coincidence++; }
            }
            return (decimal)coincidence / noise.Count;
        }
    }
}
